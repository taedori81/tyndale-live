--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.wagtailusers_userprofile DROP CONSTRAINT wagtailusers_use_user_id_140087ff955baad8_fk_customuser_user_id;
ALTER TABLE ONLY public.wagtailsearch_editorspick DROP CONSTRAINT wagtailsearch_e_page_id_361eed8faee37b94_fk_wagtailcore_page_id;
ALTER TABLE ONLY public.wagtailsearch_editorspick DROP CONSTRAINT wagtailsear_query_id_70b4a2d234a4eab8_fk_wagtailsearch_query_id;
ALTER TABLE ONLY public.wagtailsearch_querydailyhits DROP CONSTRAINT wagtailsear_query_id_541f82ef755c7a39_fk_wagtailsearch_query_id;
ALTER TABLE ONLY public.wagtailredirects_redirect DROP CONSTRAINT wagtailredirect_site_id_7b7af15c0e80cbd4_fk_wagtailcore_site_id;
ALTER TABLE ONLY public.wagtailimages_rendition DROP CONSTRAINT wagtailimag_image_id_2c8ddec62fb6f84b_fk_wagtailimages_image_id;
ALTER TABLE ONLY public.wagtailimages_rendition DROP CONSTRAINT wagtailim_filter_id_6afc387f605dd75c_fk_wagtailimages_filter_id;
ALTER TABLE ONLY public.wagtailforms_formsubmission DROP CONSTRAINT wagtailforms_fo_page_id_7776d182b41d08b3_fk_wagtailcore_page_id;
ALTER TABLE ONLY public.wagtailcore_pagerevision DROP CONSTRAINT wagtailcore_page_user_id_482fed05cd73a514_fk_customuser_user_id;
ALTER TABLE ONLY public.wagtailcore_pagerevision DROP CONSTRAINT wagtailcore_pag_page_id_7a085a6a003c2e38_fk_wagtailcore_page_id;
ALTER TABLE ONLY public.wagtailcore_pageviewrestriction DROP CONSTRAINT wagtailcore_pag_page_id_3696fe3bd41be929_fk_wagtailcore_page_id;
ALTER TABLE ONLY public.wagtailcore_page DROP CONSTRAINT wagtailcore_pag_owner_id_769ea693e7256f60_fk_customuser_user_id;
ALTER TABLE ONLY public.wagtailcore_grouppagepermission DROP CONSTRAINT wagtailcore_grouppag_group_id_5e2917ffb767a184_fk_auth_group_id;
ALTER TABLE ONLY public.wagtailcore_grouppagepermission DROP CONSTRAINT wagtailcore_gro_page_id_7b225fb90aae2549_fk_wagtailcore_page_id;
ALTER TABLE ONLY public.wagtailcore_site DROP CONSTRAINT wagtailcor_root_page_id_3e30e080d28213b6_fk_wagtailcore_page_id;
ALTER TABLE ONLY public.wagtailredirects_redirect DROP CONSTRAINT wagtai_redirect_page_id_1fc1037e8cf399c4_fk_wagtailcore_page_id;
ALTER TABLE ONLY public.wagtailimages_image DROP CONSTRAINT wagt_uploaded_by_user_id_5f678b0be96600c4_fk_customuser_user_id;
ALTER TABLE ONLY public.wagtaildocs_document DROP CONSTRAINT wagt_uploaded_by_user_id_10a3f7343c7d6b4b_fk_customuser_user_id;
ALTER TABLE ONLY public.wagtailcore_page DROP CONSTRAINT wagt_content_type_id_41104bd3511ee9a9_fk_django_content_type_id;
ALTER TABLE ONLY public.taggit_taggeditem DROP CONSTRAINT taggit_taggeditem_tag_id_626bb7c335f8c891_fk_taggit_tag_id;
ALTER TABLE ONLY public.taggit_taggeditem DROP CONSTRAINT taggi_content_type_id_de04cbca87b0d2f_fk_django_content_type_id;
ALTER TABLE ONLY public.profiles_profile DROP CONSTRAINT profiles_profile_user_id_43e45dad59676234_fk_customuser_user_id;
ALTER TABLE ONLY public.home_staffpage DROP CONSTRAINT home_staffpa_page_ptr_id_b083750d8f35a16_fk_wagtailcore_page_id;
ALTER TABLE ONLY public.home_professor DROP CONSTRAINT home_professor_course_id_702e5833cbb57b14_fk_home_course_id;
ALTER TABLE ONLY public.home_presidentpage DROP CONSTRAINT home_presid_page_ptr_id_62a75680a588fca1_fk_wagtailcore_page_id;
ALTER TABLE ONLY public.home_missionpage DROP CONSTRAINT home_missio_page_ptr_id_3200f609e1182c3e_fk_wagtailcore_page_id;
ALTER TABLE ONLY public.home_missionpage DROP CONSTRAINT home_mi_main_image_id_bf5488bee3e0be7_fk_wagtailimages_image_id;
ALTER TABLE ONLY public.home_homepage DROP CONSTRAINT home_homepa_page_ptr_id_6b97572f83da83b6_fk_wagtailcore_page_id;
ALTER TABLE ONLY public.home_formfield DROP CONSTRAINT home_fo_page_id_540def10bdd5c57_fk_home_contactpage_page_ptr_id;
ALTER TABLE ONLY public.home_faithpage DROP CONSTRAINT home_faithp_page_ptr_id_6b5dbc2cfc940b8f_fk_wagtailcore_page_id;
ALTER TABLE ONLY public.home_facultypage DROP CONSTRAINT home_faculty_page_ptr_id_1dae642e5fc50d5_fk_wagtailcore_page_id;
ALTER TABLE ONLY public.home_faithpage DROP CONSTRAINT home_f_main_image_id_4b4f54024b44b47a_fk_wagtailimages_image_id;
ALTER TABLE ONLY public.home_contactpage DROP CONSTRAINT home_contac_page_ptr_id_54acbe67b0bbcf72_fk_wagtailcore_page_id;
ALTER TABLE ONLY public.home_chairmanpage DROP CONSTRAINT home_chairm_page_ptr_id_769fe7b654b96b85_fk_wagtailcore_page_id;
ALTER TABLE ONLY public.home_admissionpage DROP CONSTRAINT home_admiss_page_ptr_id_4447d3be7c0844f6_fk_wagtailcore_page_id;
ALTER TABLE ONLY public.home_academicprogrampage DROP CONSTRAINT home_academi_page_ptr_id_cf5b0d97595723c_fk_wagtailcore_page_id;
ALTER TABLE ONLY public.home_academicpage DROP CONSTRAINT home_academ_page_ptr_id_55dae9875faad55d_fk_wagtailcore_page_id;
ALTER TABLE ONLY public.home_aboutpage DROP CONSTRAINT home_aboutp_page_ptr_id_4a7f55b5d4af4fe6_fk_wagtailcore_page_id;
ALTER TABLE ONLY public.home_aboutpage DROP CONSTRAINT home_a_main_image_id_5da9735a12d9d323_fk_wagtailimages_image_id;
ALTER TABLE ONLY public.home_academicpage DROP CONSTRAINT home_a_main_image_id_48830c21360335ac_fk_wagtailimages_image_id;
ALTER TABLE ONLY public.home_admissionpage DROP CONSTRAINT home_a_main_image_id_341d070af76ca64d_fk_wagtailimages_image_id;
ALTER TABLE ONLY public.home_professor DROP CONSTRAINT ho_professor_image_id_48877a08374a4d2_fk_wagtailimages_image_id;
ALTER TABLE ONLY public.home_chairmanpage DROP CONSTRAINT ho_chairman_image_id_560f09c64138fe11_fk_wagtailimages_image_id;
ALTER TABLE ONLY public.home_adjunctprofessor DROP CONSTRAINT h_professor_image_id_4df2333f2c01e3b1_fk_wagtailimages_image_id;
ALTER TABLE ONLY public.home_presidentpage DROP CONSTRAINT h_president_image_id_5b6916ce316916f9_fk_wagtailimages_image_id;
ALTER TABLE ONLY public.home_staffpage DROP CONSTRAINT fd8df23644a5bfe320428e6a741c48da;
ALTER TABLE ONLY public.home_staffpage DROP CONSTRAINT ec6cc53404e4a4ee3f3e85f90f0b07cd;
ALTER TABLE ONLY public.easy_thumbnails_thumbnail DROP CONSTRAINT easy_th_source_id_321805aede6687c9_fk_easy_thumbnails_source_id;
ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions DROP CONSTRAINT e_thumbnail_id_3e013d57ce7e94cb_fk_easy_thumbnails_thumbnail_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_user_id_78f04b5cdc41908b_fk_customuser_user_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT djan_content_type_id_6a613939832fcaa7_fk_django_content_type_id;
ALTER TABLE ONLY public.customuser_user_groups DROP CONSTRAINT customuser_user_groups_group_id_2f7fdf258880a2_fk_auth_group_id;
ALTER TABLE ONLY public.customuser_user_user_permissions DROP CONSTRAINT customuser_user__user_id_25455e421d51c4de_fk_customuser_user_id;
ALTER TABLE ONLY public.customuser_user_groups DROP CONSTRAINT customuser_user__user_id_231de73d12ca3cd3_fk_customuser_user_id;
ALTER TABLE ONLY public.customuser_user_user_permissions DROP CONSTRAINT customuser_permission_id_77bfc76393ec8d65_fk_auth_permission_id;
ALTER TABLE ONLY public.home_staffpage DROP CONSTRAINT c1ac98a69b14ccd9c1595f81c3822d18;
ALTER TABLE ONLY public.home_staffpage DROP CONSTRAINT bf4b8a9dd09e1b56f992b1b4b6d62dbf;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permission_id_52013bedfbcc4057_fk_auth_permission_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permission_group_id_57fc07628a848d9_fk_auth_group_id;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_content_type_id_426ec875366b3dda_fk_django_content_type_id;
ALTER TABLE ONLY public.home_staffpage DROP CONSTRAINT "D2f0c6e3dccb01e002c5eed7060c3b9a";
DROP INDEX public.wagtailsearch_querydailyhits_0bbeda9c;
DROP INDEX public.wagtailsearch_query_query_string_6a2554201de9f1b_like;
DROP INDEX public.wagtailsearch_editorspick_1a63c800;
DROP INDEX public.wagtailsearch_editorspick_0bbeda9c;
DROP INDEX public.wagtailredirects_redirect_old_path_610b66b8a211c03b_like;
DROP INDEX public.wagtailredirects_redirect_9365d6e7;
DROP INDEX public.wagtailredirects_redirect_2fd79f37;
DROP INDEX public.wagtailimages_rendition_f33175e6;
DROP INDEX public.wagtailimages_rendition_0a317463;
DROP INDEX public.wagtailimages_image_ef01e2b6;
DROP INDEX public.wagtailimages_filter_spec_409923649c6ba3fd_like;
DROP INDEX public.wagtailimages_filter_b979c293;
DROP INDEX public.wagtailforms_formsubmission_1a63c800;
DROP INDEX public.wagtaildocs_document_ef01e2b6;
DROP INDEX public.wagtailcore_site_hostname_3ffbf6d0334f7d6a_like;
DROP INDEX public.wagtailcore_site_8372b497;
DROP INDEX public.wagtailcore_site_0897acf4;
DROP INDEX public.wagtailcore_pageviewrestriction_1a63c800;
DROP INDEX public.wagtailcore_pagerevision_e8701ad4;
DROP INDEX public.wagtailcore_pagerevision_1a63c800;
DROP INDEX public.wagtailcore_page_slug_33cd6a503184f996_like;
DROP INDEX public.wagtailcore_page_path_1d96dbce42ce3047_like;
DROP INDEX public.wagtailcore_page_5e7b1936;
DROP INDEX public.wagtailcore_page_417f1b1c;
DROP INDEX public.wagtailcore_page_2dbcba41;
DROP INDEX public.wagtailcore_grouppagepermission_1a63c800;
DROP INDEX public.wagtailcore_grouppagepermission_0e939a4f;
DROP INDEX public.taggit_taggeditem_af31437c;
DROP INDEX public.taggit_taggeditem_76f094bc;
DROP INDEX public.taggit_taggeditem_417f1b1c;
DROP INDEX public.taggit_tag_slug_7b53216b5eb30e7a_like;
DROP INDEX public.taggit_tag_name_352a4f53e1e6cf47_like;
DROP INDEX public.home_staffpage_ba834c48;
DROP INDEX public.home_staffpage_b238208f;
DROP INDEX public.home_staffpage_a18b3be8;
DROP INDEX public.home_staffpage_6f0924fe;
DROP INDEX public.home_staffpage_225a5e91;
DROP INDEX public.home_professor_ea134da7;
DROP INDEX public.home_professor_628c0510;
DROP INDEX public.home_presidentpage_95be3c30;
DROP INDEX public.home_missionpage_36b62cbe;
DROP INDEX public.home_formfield_1a63c800;
DROP INDEX public.home_faithpage_36b62cbe;
DROP INDEX public.home_chairmanpage_c24e8e1f;
DROP INDEX public.home_admissionpage_36b62cbe;
DROP INDEX public.home_adjunctprofessor_628c0510;
DROP INDEX public.home_academicpage_36b62cbe;
DROP INDEX public.home_aboutpage_36b62cbe;
DROP INDEX public.easy_thumbnails_thumbnail_storage_hash_6f4dc48e20d434c1_like;
DROP INDEX public.easy_thumbnails_thumbnail_name_c03c5337b1aa13c_like;
DROP INDEX public.easy_thumbnails_thumbnail_b454e115;
DROP INDEX public.easy_thumbnails_thumbnail_b068931c;
DROP INDEX public.easy_thumbnails_thumbnail_0afd9202;
DROP INDEX public.easy_thumbnails_source_storage_hash_417781e295d0ceee_like;
DROP INDEX public.easy_thumbnails_source_name_38cbc7eb65fc261b_like;
DROP INDEX public.easy_thumbnails_source_b454e115;
DROP INDEX public.easy_thumbnails_source_b068931c;
DROP INDEX public.django_session_session_key_3fb33b5fdd87a86f_like;
DROP INDEX public.django_session_de54fa62;
DROP INDEX public.django_admin_log_e8701ad4;
DROP INDEX public.django_admin_log_417f1b1c;
DROP INDEX public.customuser_user_user_permissions_e8701ad4;
DROP INDEX public.customuser_user_user_permissions_8373b171;
DROP INDEX public.customuser_user_groups_e8701ad4;
DROP INDEX public.customuser_user_groups_0e939a4f;
DROP INDEX public.customuser_user_email_159630748200931_like;
DROP INDEX public.auth_permission_417f1b1c;
DROP INDEX public.auth_group_permissions_8373b171;
DROP INDEX public.auth_group_permissions_0e939a4f;
DROP INDEX public.auth_group_name_7665a36bbdb67308_like;
ALTER TABLE ONLY public.wagtailusers_userprofile DROP CONSTRAINT wagtailusers_userprofile_user_id_key;
ALTER TABLE ONLY public.wagtailusers_userprofile DROP CONSTRAINT wagtailusers_userprofile_pkey;
ALTER TABLE ONLY public.wagtailsearch_querydailyhits DROP CONSTRAINT wagtailsearch_querydailyhits_query_id_79086747560278_uniq;
ALTER TABLE ONLY public.wagtailsearch_querydailyhits DROP CONSTRAINT wagtailsearch_querydailyhits_pkey;
ALTER TABLE ONLY public.wagtailsearch_query DROP CONSTRAINT wagtailsearch_query_query_string_key;
ALTER TABLE ONLY public.wagtailsearch_query DROP CONSTRAINT wagtailsearch_query_pkey;
ALTER TABLE ONLY public.wagtailsearch_editorspick DROP CONSTRAINT wagtailsearch_editorspick_pkey;
ALTER TABLE ONLY public.wagtailredirects_redirect DROP CONSTRAINT wagtailredirects_redirect_pkey;
ALTER TABLE ONLY public.wagtailredirects_redirect DROP CONSTRAINT wagtailredirects_redirect_old_path_key;
ALTER TABLE ONLY public.wagtailimages_rendition DROP CONSTRAINT wagtailimages_rendition_pkey;
ALTER TABLE ONLY public.wagtailimages_rendition DROP CONSTRAINT wagtailimages_rendition_image_id_490eb468027bb6fd_uniq;
ALTER TABLE ONLY public.wagtailimages_image DROP CONSTRAINT wagtailimages_image_pkey;
ALTER TABLE ONLY public.wagtailimages_filter DROP CONSTRAINT wagtailimages_filter_spec_409923649c6ba3fd_uniq;
ALTER TABLE ONLY public.wagtailimages_filter DROP CONSTRAINT wagtailimages_filter_pkey;
ALTER TABLE ONLY public.wagtailforms_formsubmission DROP CONSTRAINT wagtailforms_formsubmission_pkey;
ALTER TABLE ONLY public.wagtailembeds_embed DROP CONSTRAINT wagtailembeds_embed_url_7e0691a718dc9c01_uniq;
ALTER TABLE ONLY public.wagtailembeds_embed DROP CONSTRAINT wagtailembeds_embed_pkey;
ALTER TABLE ONLY public.wagtaildocs_document DROP CONSTRAINT wagtaildocs_document_pkey;
ALTER TABLE ONLY public.wagtailcore_site DROP CONSTRAINT wagtailcore_site_pkey;
ALTER TABLE ONLY public.wagtailcore_site DROP CONSTRAINT wagtailcore_site_hostname_2a80ef61b26e6749_uniq;
ALTER TABLE ONLY public.wagtailcore_pageviewrestriction DROP CONSTRAINT wagtailcore_pageviewrestriction_pkey;
ALTER TABLE ONLY public.wagtailcore_pagerevision DROP CONSTRAINT wagtailcore_pagerevision_pkey;
ALTER TABLE ONLY public.wagtailcore_page DROP CONSTRAINT wagtailcore_page_pkey;
ALTER TABLE ONLY public.wagtailcore_page DROP CONSTRAINT wagtailcore_page_path_key;
ALTER TABLE ONLY public.wagtailcore_grouppagepermission DROP CONSTRAINT wagtailcore_grouppagepermission_pkey;
ALTER TABLE ONLY public.wagtailcore_grouppagepermission DROP CONSTRAINT wagtailcore_grouppagepermission_group_id_4518bd8ce5687df9_uniq;
ALTER TABLE ONLY public.taggit_taggeditem DROP CONSTRAINT taggit_taggeditem_pkey;
ALTER TABLE ONLY public.taggit_tag DROP CONSTRAINT taggit_tag_slug_key;
ALTER TABLE ONLY public.taggit_tag DROP CONSTRAINT taggit_tag_pkey;
ALTER TABLE ONLY public.taggit_tag DROP CONSTRAINT taggit_tag_name_key;
ALTER TABLE ONLY public.profiles_profile DROP CONSTRAINT profiles_profile_pkey;
ALTER TABLE ONLY public.home_staffpage DROP CONSTRAINT home_staffpage_pkey;
ALTER TABLE ONLY public.home_professor DROP CONSTRAINT home_professor_pkey;
ALTER TABLE ONLY public.home_presidentpage DROP CONSTRAINT home_presidentpage_pkey;
ALTER TABLE ONLY public.home_missionpage DROP CONSTRAINT home_missionpage_pkey;
ALTER TABLE ONLY public.home_homepage DROP CONSTRAINT home_homepage_pkey;
ALTER TABLE ONLY public.home_formfield DROP CONSTRAINT home_formfield_pkey;
ALTER TABLE ONLY public.home_faithpage DROP CONSTRAINT home_faithpage_pkey;
ALTER TABLE ONLY public.home_facultypage DROP CONSTRAINT home_facultypage_pkey;
ALTER TABLE ONLY public.home_course DROP CONSTRAINT home_course_pkey;
ALTER TABLE ONLY public.home_contactpage DROP CONSTRAINT home_contactpage_pkey;
ALTER TABLE ONLY public.home_chairmanpage DROP CONSTRAINT home_chairmanpage_pkey;
ALTER TABLE ONLY public.home_admissionpage DROP CONSTRAINT home_admissionpage_pkey;
ALTER TABLE ONLY public.home_adjunctprofessor DROP CONSTRAINT home_adjunctprofessor_pkey;
ALTER TABLE ONLY public.home_academicprograms DROP CONSTRAINT home_academicprograms_pkey;
ALTER TABLE ONLY public.home_academicprogrampage DROP CONSTRAINT home_academicprogrampage_pkey;
ALTER TABLE ONLY public.home_academicpage DROP CONSTRAINT home_academicpage_pkey;
ALTER TABLE ONLY public.home_aboutpage DROP CONSTRAINT home_aboutpage_pkey;
ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions DROP CONSTRAINT easy_thumbnails_thumbnaildimensions_thumbnail_id_key;
ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions DROP CONSTRAINT easy_thumbnails_thumbnaildimensions_pkey;
ALTER TABLE ONLY public.easy_thumbnails_thumbnail DROP CONSTRAINT easy_thumbnails_thumbnail_storage_hash_395d1722d4748222_uniq;
ALTER TABLE ONLY public.easy_thumbnails_thumbnail DROP CONSTRAINT easy_thumbnails_thumbnail_pkey;
ALTER TABLE ONLY public.easy_thumbnails_source DROP CONSTRAINT easy_thumbnails_source_storage_hash_98d060f8ac60bfa_uniq;
ALTER TABLE ONLY public.easy_thumbnails_source DROP CONSTRAINT easy_thumbnails_source_pkey;
ALTER TABLE ONLY public.django_session DROP CONSTRAINT django_session_pkey;
ALTER TABLE ONLY public.django_migrations DROP CONSTRAINT django_migrations_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_app_label_dc43af67bcef15c_uniq;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_pkey;
ALTER TABLE ONLY public.customuser_user_user_permissions DROP CONSTRAINT customuser_user_user_permissions_user_id_permission_id_key;
ALTER TABLE ONLY public.customuser_user_user_permissions DROP CONSTRAINT customuser_user_user_permissions_pkey;
ALTER TABLE ONLY public.customuser_user DROP CONSTRAINT customuser_user_pkey;
ALTER TABLE ONLY public.customuser_user_groups DROP CONSTRAINT customuser_user_groups_user_id_group_id_key;
ALTER TABLE ONLY public.customuser_user_groups DROP CONSTRAINT customuser_user_groups_pkey;
ALTER TABLE ONLY public.customuser_user DROP CONSTRAINT customuser_user_email_key;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_codename_key;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_permission_id_key;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_name_key;
ALTER TABLE public.wagtailusers_userprofile ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.wagtailsearch_querydailyhits ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.wagtailsearch_query ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.wagtailsearch_editorspick ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.wagtailredirects_redirect ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.wagtailimages_rendition ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.wagtailimages_image ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.wagtailimages_filter ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.wagtailforms_formsubmission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.wagtailembeds_embed ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.wagtaildocs_document ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.wagtailcore_site ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.wagtailcore_pageviewrestriction ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.wagtailcore_pagerevision ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.wagtailcore_page ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.wagtailcore_grouppagepermission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.taggit_taggeditem ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.taggit_tag ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.home_professor ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.home_formfield ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.home_course ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.home_adjunctprofessor ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.home_academicprograms ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.easy_thumbnails_thumbnaildimensions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.easy_thumbnails_thumbnail ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.easy_thumbnails_source ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_content_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_admin_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.customuser_user_user_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.customuser_user_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.customuser_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_permission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.wagtailusers_userprofile_id_seq;
DROP TABLE public.wagtailusers_userprofile;
DROP SEQUENCE public.wagtailsearch_querydailyhits_id_seq;
DROP TABLE public.wagtailsearch_querydailyhits;
DROP SEQUENCE public.wagtailsearch_query_id_seq;
DROP TABLE public.wagtailsearch_query;
DROP SEQUENCE public.wagtailsearch_editorspick_id_seq;
DROP TABLE public.wagtailsearch_editorspick;
DROP SEQUENCE public.wagtailredirects_redirect_id_seq;
DROP TABLE public.wagtailredirects_redirect;
DROP SEQUENCE public.wagtailimages_rendition_id_seq;
DROP TABLE public.wagtailimages_rendition;
DROP SEQUENCE public.wagtailimages_image_id_seq;
DROP TABLE public.wagtailimages_image;
DROP SEQUENCE public.wagtailimages_filter_id_seq;
DROP TABLE public.wagtailimages_filter;
DROP SEQUENCE public.wagtailforms_formsubmission_id_seq;
DROP TABLE public.wagtailforms_formsubmission;
DROP SEQUENCE public.wagtailembeds_embed_id_seq;
DROP TABLE public.wagtailembeds_embed;
DROP SEQUENCE public.wagtaildocs_document_id_seq;
DROP TABLE public.wagtaildocs_document;
DROP SEQUENCE public.wagtailcore_site_id_seq;
DROP TABLE public.wagtailcore_site;
DROP SEQUENCE public.wagtailcore_pageviewrestriction_id_seq;
DROP TABLE public.wagtailcore_pageviewrestriction;
DROP SEQUENCE public.wagtailcore_pagerevision_id_seq;
DROP TABLE public.wagtailcore_pagerevision;
DROP SEQUENCE public.wagtailcore_page_id_seq;
DROP TABLE public.wagtailcore_page;
DROP SEQUENCE public.wagtailcore_grouppagepermission_id_seq;
DROP TABLE public.wagtailcore_grouppagepermission;
DROP SEQUENCE public.taggit_taggeditem_id_seq;
DROP TABLE public.taggit_taggeditem;
DROP SEQUENCE public.taggit_tag_id_seq;
DROP TABLE public.taggit_tag;
DROP TABLE public.profiles_profile;
DROP TABLE public.home_staffpage;
DROP SEQUENCE public.home_professor_id_seq;
DROP TABLE public.home_professor;
DROP TABLE public.home_presidentpage;
DROP TABLE public.home_missionpage;
DROP TABLE public.home_homepage;
DROP SEQUENCE public.home_formfield_id_seq;
DROP TABLE public.home_formfield;
DROP TABLE public.home_faithpage;
DROP TABLE public.home_facultypage;
DROP SEQUENCE public.home_course_id_seq;
DROP TABLE public.home_course;
DROP TABLE public.home_contactpage;
DROP TABLE public.home_chairmanpage;
DROP TABLE public.home_admissionpage;
DROP SEQUENCE public.home_adjunctprofessor_id_seq;
DROP TABLE public.home_adjunctprofessor;
DROP SEQUENCE public.home_academicprograms_id_seq;
DROP TABLE public.home_academicprograms;
DROP TABLE public.home_academicprogrampage;
DROP TABLE public.home_academicpage;
DROP TABLE public.home_aboutpage;
DROP SEQUENCE public.easy_thumbnails_thumbnaildimensions_id_seq;
DROP TABLE public.easy_thumbnails_thumbnaildimensions;
DROP SEQUENCE public.easy_thumbnails_thumbnail_id_seq;
DROP TABLE public.easy_thumbnails_thumbnail;
DROP SEQUENCE public.easy_thumbnails_source_id_seq;
DROP TABLE public.easy_thumbnails_source;
DROP TABLE public.django_session;
DROP SEQUENCE public.django_migrations_id_seq;
DROP TABLE public.django_migrations;
DROP SEQUENCE public.django_content_type_id_seq;
DROP TABLE public.django_content_type;
DROP SEQUENCE public.django_admin_log_id_seq;
DROP TABLE public.django_admin_log;
DROP SEQUENCE public.customuser_user_user_permissions_id_seq;
DROP TABLE public.customuser_user_user_permissions;
DROP SEQUENCE public.customuser_user_id_seq;
DROP SEQUENCE public.customuser_user_groups_id_seq;
DROP TABLE public.customuser_user_groups;
DROP TABLE public.customuser_user;
DROP SEQUENCE public.auth_permission_id_seq;
DROP TABLE public.auth_permission;
DROP SEQUENCE public.auth_group_permissions_id_seq;
DROP TABLE public.auth_group_permissions;
DROP SEQUENCE public.auth_group_id_seq;
DROP TABLE public.auth_group;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO tyndale;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO tyndale;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO tyndale;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO tyndale;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO tyndale;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO tyndale;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: customuser_user; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE customuser_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    email character varying(255) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    last_name character varying(255) NOT NULL,
    first_name character varying(255) NOT NULL
);


ALTER TABLE public.customuser_user OWNER TO tyndale;

--
-- Name: customuser_user_groups; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE customuser_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.customuser_user_groups OWNER TO tyndale;

--
-- Name: customuser_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE customuser_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customuser_user_groups_id_seq OWNER TO tyndale;

--
-- Name: customuser_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE customuser_user_groups_id_seq OWNED BY customuser_user_groups.id;


--
-- Name: customuser_user_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE customuser_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customuser_user_id_seq OWNER TO tyndale;

--
-- Name: customuser_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE customuser_user_id_seq OWNED BY customuser_user.id;


--
-- Name: customuser_user_user_permissions; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE customuser_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.customuser_user_user_permissions OWNER TO tyndale;

--
-- Name: customuser_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE customuser_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customuser_user_user_permissions_id_seq OWNER TO tyndale;

--
-- Name: customuser_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE customuser_user_user_permissions_id_seq OWNED BY customuser_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO tyndale;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO tyndale;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO tyndale;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO tyndale;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO tyndale;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO tyndale;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO tyndale;

--
-- Name: easy_thumbnails_source; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE easy_thumbnails_source (
    id integer NOT NULL,
    storage_hash character varying(40) NOT NULL,
    name character varying(255) NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE public.easy_thumbnails_source OWNER TO tyndale;

--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE easy_thumbnails_source_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.easy_thumbnails_source_id_seq OWNER TO tyndale;

--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE easy_thumbnails_source_id_seq OWNED BY easy_thumbnails_source.id;


--
-- Name: easy_thumbnails_thumbnail; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE easy_thumbnails_thumbnail (
    id integer NOT NULL,
    storage_hash character varying(40) NOT NULL,
    name character varying(255) NOT NULL,
    modified timestamp with time zone NOT NULL,
    source_id integer NOT NULL
);


ALTER TABLE public.easy_thumbnails_thumbnail OWNER TO tyndale;

--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE easy_thumbnails_thumbnail_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.easy_thumbnails_thumbnail_id_seq OWNER TO tyndale;

--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE easy_thumbnails_thumbnail_id_seq OWNED BY easy_thumbnails_thumbnail.id;


--
-- Name: easy_thumbnails_thumbnaildimensions; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE easy_thumbnails_thumbnaildimensions (
    id integer NOT NULL,
    thumbnail_id integer NOT NULL,
    width integer,
    height integer,
    CONSTRAINT easy_thumbnails_thumbnaildimensions_height_check CHECK ((height >= 0)),
    CONSTRAINT easy_thumbnails_thumbnaildimensions_width_check CHECK ((width >= 0))
);


ALTER TABLE public.easy_thumbnails_thumbnaildimensions OWNER TO tyndale;

--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE easy_thumbnails_thumbnaildimensions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.easy_thumbnails_thumbnaildimensions_id_seq OWNER TO tyndale;

--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE easy_thumbnails_thumbnaildimensions_id_seq OWNED BY easy_thumbnails_thumbnaildimensions.id;


--
-- Name: home_aboutpage; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE home_aboutpage (
    page_ptr_id integer NOT NULL,
    subsection_title character varying(30) NOT NULL,
    subsection_subtitle character varying(100) NOT NULL,
    body text NOT NULL,
    main_image_id integer
);


ALTER TABLE public.home_aboutpage OWNER TO tyndale;

--
-- Name: home_academicpage; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE home_academicpage (
    page_ptr_id integer NOT NULL,
    subsection_title character varying(30) NOT NULL,
    subsection_subtitle character varying(100) NOT NULL,
    body text NOT NULL,
    main_image_id integer
);


ALTER TABLE public.home_academicpage OWNER TO tyndale;

--
-- Name: home_academicprogrampage; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE home_academicprogrampage (
    page_ptr_id integer NOT NULL,
    subsection_title character varying(30) NOT NULL,
    subsection_subtitle character varying(100) NOT NULL
);


ALTER TABLE public.home_academicprogrampage OWNER TO tyndale;

--
-- Name: home_academicprograms; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE home_academicprograms (
    id integer NOT NULL,
    program_name character varying(50) NOT NULL,
    program_description text NOT NULL
);


ALTER TABLE public.home_academicprograms OWNER TO tyndale;

--
-- Name: home_academicprograms_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE home_academicprograms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.home_academicprograms_id_seq OWNER TO tyndale;

--
-- Name: home_academicprograms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE home_academicprograms_id_seq OWNED BY home_academicprograms.id;


--
-- Name: home_adjunctprofessor; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE home_adjunctprofessor (
    id integer NOT NULL,
    professor_name character varying(30) NOT NULL,
    professor_spec text NOT NULL,
    professor_course character varying(100) NOT NULL,
    professor_image_id integer
);


ALTER TABLE public.home_adjunctprofessor OWNER TO tyndale;

--
-- Name: home_adjunctprofessor_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE home_adjunctprofessor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.home_adjunctprofessor_id_seq OWNER TO tyndale;

--
-- Name: home_adjunctprofessor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE home_adjunctprofessor_id_seq OWNED BY home_adjunctprofessor.id;


--
-- Name: home_admissionpage; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE home_admissionpage (
    page_ptr_id integer NOT NULL,
    subsection_title character varying(30) NOT NULL,
    subsection_subtitle character varying(100) NOT NULL,
    body text NOT NULL,
    main_image_id integer
);


ALTER TABLE public.home_admissionpage OWNER TO tyndale;

--
-- Name: home_chairmanpage; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE home_chairmanpage (
    page_ptr_id integer NOT NULL,
    subsection_title character varying(30) NOT NULL,
    subsection_subtitle character varying(100) NOT NULL,
    chairman_name character varying(30) NOT NULL,
    chairman_title character varying(20) NOT NULL,
    body text NOT NULL,
    chairman_image_id integer
);


ALTER TABLE public.home_chairmanpage OWNER TO tyndale;

--
-- Name: home_contactpage; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE home_contactpage (
    page_ptr_id integer NOT NULL,
    to_address character varying(255) NOT NULL,
    from_address character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    contact_header character varying(30) NOT NULL,
    contact_subheader character varying(100) NOT NULL,
    thank_you_text character varying(255) NOT NULL
);


ALTER TABLE public.home_contactpage OWNER TO tyndale;

--
-- Name: home_course; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE home_course (
    id integer NOT NULL,
    course_name character varying(100) NOT NULL
);


ALTER TABLE public.home_course OWNER TO tyndale;

--
-- Name: home_course_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE home_course_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.home_course_id_seq OWNER TO tyndale;

--
-- Name: home_course_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE home_course_id_seq OWNED BY home_course.id;


--
-- Name: home_facultypage; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE home_facultypage (
    page_ptr_id integer NOT NULL,
    subsection_title character varying(30) NOT NULL,
    subsection_subtitle character varying(100) NOT NULL,
    tab_title_1 character varying(30) NOT NULL,
    tab_title_2 character varying(30) NOT NULL
);


ALTER TABLE public.home_facultypage OWNER TO tyndale;

--
-- Name: home_faithpage; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE home_faithpage (
    page_ptr_id integer NOT NULL,
    subsection_title character varying(30) NOT NULL,
    subsection_subtitle character varying(100) NOT NULL,
    body text NOT NULL,
    main_image_id integer
);


ALTER TABLE public.home_faithpage OWNER TO tyndale;

--
-- Name: home_formfield; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE home_formfield (
    id integer NOT NULL,
    sort_order integer,
    label character varying(255) NOT NULL,
    field_type character varying(16) NOT NULL,
    required boolean NOT NULL,
    choices character varying(512) NOT NULL,
    default_value character varying(255) NOT NULL,
    help_text character varying(255) NOT NULL,
    page_id integer NOT NULL
);


ALTER TABLE public.home_formfield OWNER TO tyndale;

--
-- Name: home_formfield_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE home_formfield_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.home_formfield_id_seq OWNER TO tyndale;

--
-- Name: home_formfield_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE home_formfield_id_seq OWNED BY home_formfield.id;


--
-- Name: home_homepage; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE home_homepage (
    page_ptr_id integer NOT NULL,
    main_header character varying(30) NOT NULL,
    main_subheader character varying(255) NOT NULL,
    slider1_header1 character varying(30) NOT NULL,
    slider1_header2 character varying(50) NOT NULL,
    slider1_subheader1 character varying(100) NOT NULL,
    slider2_header1 character varying(255) NOT NULL,
    slider2_subheader1 character varying(30) NOT NULL
);


ALTER TABLE public.home_homepage OWNER TO tyndale;

--
-- Name: home_missionpage; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE home_missionpage (
    page_ptr_id integer NOT NULL,
    subsection_title character varying(30) NOT NULL,
    subsection_subtitle character varying(100) NOT NULL,
    body text NOT NULL,
    main_image_id integer
);


ALTER TABLE public.home_missionpage OWNER TO tyndale;

--
-- Name: home_presidentpage; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE home_presidentpage (
    page_ptr_id integer NOT NULL,
    subsection_title character varying(30) NOT NULL,
    subsection_subtitle character varying(100) NOT NULL,
    president_name character varying(30) NOT NULL,
    president_title character varying(20) NOT NULL,
    body text NOT NULL,
    president_image_id integer
);


ALTER TABLE public.home_presidentpage OWNER TO tyndale;

--
-- Name: home_professor; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE home_professor (
    id integer NOT NULL,
    professor_name character varying(30) NOT NULL,
    professor_spec text NOT NULL,
    course_id integer,
    professor_image_id integer
);


ALTER TABLE public.home_professor OWNER TO tyndale;

--
-- Name: home_professor_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE home_professor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.home_professor_id_seq OWNER TO tyndale;

--
-- Name: home_professor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE home_professor_id_seq OWNED BY home_professor.id;


--
-- Name: home_staffpage; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE home_staffpage (
    page_ptr_id integer NOT NULL,
    subsection_title character varying(30) NOT NULL,
    subsection_subtitle character varying(100) NOT NULL,
    first_column_header character varying(30) NOT NULL,
    first_column_name character varying(30) NOT NULL,
    first_column_position character varying(30) NOT NULL,
    first_column_spec text NOT NULL,
    second_column_header character varying(30) NOT NULL,
    second_column_name character varying(30) NOT NULL,
    second_column_position character varying(30) NOT NULL,
    second_column_spec text NOT NULL,
    third_column_header character varying(30) NOT NULL,
    third_column_name character varying(30) NOT NULL,
    third_column_position character varying(30) NOT NULL,
    fourth_column_header character varying(30) NOT NULL,
    fourth_column_name character varying(30) NOT NULL,
    fourth_column_position character varying(30) NOT NULL,
    fifth_column_header character varying(30) NOT NULL,
    fifth_column_name character varying(30) NOT NULL,
    fifth_column_position character varying(30) NOT NULL,
    fifth_column_image_id integer,
    first_column_image_id integer,
    fourth_column_image_id integer,
    second_column_image_id integer,
    third_column_image_id integer
);


ALTER TABLE public.home_staffpage OWNER TO tyndale;

--
-- Name: profiles_profile; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE profiles_profile (
    user_id integer NOT NULL,
    slug uuid NOT NULL,
    picture character varying(100),
    bio character varying(200),
    email_verified boolean NOT NULL
);


ALTER TABLE public.profiles_profile OWNER TO tyndale;

--
-- Name: taggit_tag; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE taggit_tag (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL
);


ALTER TABLE public.taggit_tag OWNER TO tyndale;

--
-- Name: taggit_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE taggit_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.taggit_tag_id_seq OWNER TO tyndale;

--
-- Name: taggit_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE taggit_tag_id_seq OWNED BY taggit_tag.id;


--
-- Name: taggit_taggeditem; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE taggit_taggeditem (
    id integer NOT NULL,
    object_id integer NOT NULL,
    content_type_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.taggit_taggeditem OWNER TO tyndale;

--
-- Name: taggit_taggeditem_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE taggit_taggeditem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.taggit_taggeditem_id_seq OWNER TO tyndale;

--
-- Name: taggit_taggeditem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE taggit_taggeditem_id_seq OWNED BY taggit_taggeditem.id;


--
-- Name: wagtailcore_grouppagepermission; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE wagtailcore_grouppagepermission (
    id integer NOT NULL,
    permission_type character varying(20) NOT NULL,
    group_id integer NOT NULL,
    page_id integer NOT NULL
);


ALTER TABLE public.wagtailcore_grouppagepermission OWNER TO tyndale;

--
-- Name: wagtailcore_grouppagepermission_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE wagtailcore_grouppagepermission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailcore_grouppagepermission_id_seq OWNER TO tyndale;

--
-- Name: wagtailcore_grouppagepermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE wagtailcore_grouppagepermission_id_seq OWNED BY wagtailcore_grouppagepermission.id;


--
-- Name: wagtailcore_page; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE wagtailcore_page (
    id integer NOT NULL,
    path character varying(255) NOT NULL,
    depth integer NOT NULL,
    numchild integer NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    live boolean NOT NULL,
    has_unpublished_changes boolean NOT NULL,
    url_path text NOT NULL,
    seo_title character varying(255) NOT NULL,
    show_in_menus boolean NOT NULL,
    search_description text NOT NULL,
    go_live_at timestamp with time zone,
    expire_at timestamp with time zone,
    expired boolean NOT NULL,
    content_type_id integer NOT NULL,
    owner_id integer,
    locked boolean NOT NULL,
    latest_revision_created_at timestamp with time zone,
    first_published_at timestamp with time zone,
    CONSTRAINT wagtailcore_page_depth_check CHECK ((depth >= 0)),
    CONSTRAINT wagtailcore_page_numchild_check CHECK ((numchild >= 0))
);


ALTER TABLE public.wagtailcore_page OWNER TO tyndale;

--
-- Name: wagtailcore_page_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE wagtailcore_page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailcore_page_id_seq OWNER TO tyndale;

--
-- Name: wagtailcore_page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE wagtailcore_page_id_seq OWNED BY wagtailcore_page.id;


--
-- Name: wagtailcore_pagerevision; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE wagtailcore_pagerevision (
    id integer NOT NULL,
    submitted_for_moderation boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    content_json text NOT NULL,
    approved_go_live_at timestamp with time zone,
    page_id integer NOT NULL,
    user_id integer
);


ALTER TABLE public.wagtailcore_pagerevision OWNER TO tyndale;

--
-- Name: wagtailcore_pagerevision_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE wagtailcore_pagerevision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailcore_pagerevision_id_seq OWNER TO tyndale;

--
-- Name: wagtailcore_pagerevision_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE wagtailcore_pagerevision_id_seq OWNED BY wagtailcore_pagerevision.id;


--
-- Name: wagtailcore_pageviewrestriction; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE wagtailcore_pageviewrestriction (
    id integer NOT NULL,
    password character varying(255) NOT NULL,
    page_id integer NOT NULL
);


ALTER TABLE public.wagtailcore_pageviewrestriction OWNER TO tyndale;

--
-- Name: wagtailcore_pageviewrestriction_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE wagtailcore_pageviewrestriction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailcore_pageviewrestriction_id_seq OWNER TO tyndale;

--
-- Name: wagtailcore_pageviewrestriction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE wagtailcore_pageviewrestriction_id_seq OWNED BY wagtailcore_pageviewrestriction.id;


--
-- Name: wagtailcore_site; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE wagtailcore_site (
    id integer NOT NULL,
    hostname character varying(255) NOT NULL,
    port integer NOT NULL,
    is_default_site boolean NOT NULL,
    root_page_id integer NOT NULL
);


ALTER TABLE public.wagtailcore_site OWNER TO tyndale;

--
-- Name: wagtailcore_site_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE wagtailcore_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailcore_site_id_seq OWNER TO tyndale;

--
-- Name: wagtailcore_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE wagtailcore_site_id_seq OWNED BY wagtailcore_site.id;


--
-- Name: wagtaildocs_document; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE wagtaildocs_document (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    file character varying(100) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    uploaded_by_user_id integer
);


ALTER TABLE public.wagtaildocs_document OWNER TO tyndale;

--
-- Name: wagtaildocs_document_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE wagtaildocs_document_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtaildocs_document_id_seq OWNER TO tyndale;

--
-- Name: wagtaildocs_document_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE wagtaildocs_document_id_seq OWNED BY wagtaildocs_document.id;


--
-- Name: wagtailembeds_embed; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE wagtailembeds_embed (
    id integer NOT NULL,
    url character varying(200) NOT NULL,
    max_width smallint,
    type character varying(10) NOT NULL,
    html text NOT NULL,
    title text NOT NULL,
    author_name text NOT NULL,
    provider_name text NOT NULL,
    thumbnail_url character varying(200),
    width integer,
    height integer,
    last_updated timestamp with time zone NOT NULL
);


ALTER TABLE public.wagtailembeds_embed OWNER TO tyndale;

--
-- Name: wagtailembeds_embed_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE wagtailembeds_embed_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailembeds_embed_id_seq OWNER TO tyndale;

--
-- Name: wagtailembeds_embed_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE wagtailembeds_embed_id_seq OWNED BY wagtailembeds_embed.id;


--
-- Name: wagtailforms_formsubmission; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE wagtailforms_formsubmission (
    id integer NOT NULL,
    form_data text NOT NULL,
    submit_time timestamp with time zone NOT NULL,
    page_id integer NOT NULL
);


ALTER TABLE public.wagtailforms_formsubmission OWNER TO tyndale;

--
-- Name: wagtailforms_formsubmission_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE wagtailforms_formsubmission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailforms_formsubmission_id_seq OWNER TO tyndale;

--
-- Name: wagtailforms_formsubmission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE wagtailforms_formsubmission_id_seq OWNED BY wagtailforms_formsubmission.id;


--
-- Name: wagtailimages_filter; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE wagtailimages_filter (
    id integer NOT NULL,
    spec character varying(255) NOT NULL
);


ALTER TABLE public.wagtailimages_filter OWNER TO tyndale;

--
-- Name: wagtailimages_filter_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE wagtailimages_filter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailimages_filter_id_seq OWNER TO tyndale;

--
-- Name: wagtailimages_filter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE wagtailimages_filter_id_seq OWNED BY wagtailimages_filter.id;


--
-- Name: wagtailimages_image; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE wagtailimages_image (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    file character varying(100) NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    focal_point_x integer,
    focal_point_y integer,
    focal_point_width integer,
    focal_point_height integer,
    uploaded_by_user_id integer,
    CONSTRAINT wagtailimages_image_focal_point_height_check CHECK ((focal_point_height >= 0)),
    CONSTRAINT wagtailimages_image_focal_point_width_check CHECK ((focal_point_width >= 0)),
    CONSTRAINT wagtailimages_image_focal_point_x_check CHECK ((focal_point_x >= 0)),
    CONSTRAINT wagtailimages_image_focal_point_y_check CHECK ((focal_point_y >= 0))
);


ALTER TABLE public.wagtailimages_image OWNER TO tyndale;

--
-- Name: wagtailimages_image_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE wagtailimages_image_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailimages_image_id_seq OWNER TO tyndale;

--
-- Name: wagtailimages_image_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE wagtailimages_image_id_seq OWNED BY wagtailimages_image.id;


--
-- Name: wagtailimages_rendition; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE wagtailimages_rendition (
    id integer NOT NULL,
    file character varying(100) NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    focal_point_key character varying(255) NOT NULL,
    filter_id integer NOT NULL,
    image_id integer NOT NULL
);


ALTER TABLE public.wagtailimages_rendition OWNER TO tyndale;

--
-- Name: wagtailimages_rendition_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE wagtailimages_rendition_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailimages_rendition_id_seq OWNER TO tyndale;

--
-- Name: wagtailimages_rendition_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE wagtailimages_rendition_id_seq OWNED BY wagtailimages_rendition.id;


--
-- Name: wagtailredirects_redirect; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE wagtailredirects_redirect (
    id integer NOT NULL,
    old_path character varying(255) NOT NULL,
    is_permanent boolean NOT NULL,
    redirect_link character varying(200) NOT NULL,
    redirect_page_id integer,
    site_id integer
);


ALTER TABLE public.wagtailredirects_redirect OWNER TO tyndale;

--
-- Name: wagtailredirects_redirect_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE wagtailredirects_redirect_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailredirects_redirect_id_seq OWNER TO tyndale;

--
-- Name: wagtailredirects_redirect_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE wagtailredirects_redirect_id_seq OWNED BY wagtailredirects_redirect.id;


--
-- Name: wagtailsearch_editorspick; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE wagtailsearch_editorspick (
    id integer NOT NULL,
    sort_order integer,
    description text NOT NULL,
    page_id integer NOT NULL,
    query_id integer NOT NULL
);


ALTER TABLE public.wagtailsearch_editorspick OWNER TO tyndale;

--
-- Name: wagtailsearch_editorspick_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE wagtailsearch_editorspick_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailsearch_editorspick_id_seq OWNER TO tyndale;

--
-- Name: wagtailsearch_editorspick_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE wagtailsearch_editorspick_id_seq OWNED BY wagtailsearch_editorspick.id;


--
-- Name: wagtailsearch_query; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE wagtailsearch_query (
    id integer NOT NULL,
    query_string character varying(255) NOT NULL
);


ALTER TABLE public.wagtailsearch_query OWNER TO tyndale;

--
-- Name: wagtailsearch_query_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE wagtailsearch_query_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailsearch_query_id_seq OWNER TO tyndale;

--
-- Name: wagtailsearch_query_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE wagtailsearch_query_id_seq OWNED BY wagtailsearch_query.id;


--
-- Name: wagtailsearch_querydailyhits; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE wagtailsearch_querydailyhits (
    id integer NOT NULL,
    date date NOT NULL,
    hits integer NOT NULL,
    query_id integer NOT NULL
);


ALTER TABLE public.wagtailsearch_querydailyhits OWNER TO tyndale;

--
-- Name: wagtailsearch_querydailyhits_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE wagtailsearch_querydailyhits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailsearch_querydailyhits_id_seq OWNER TO tyndale;

--
-- Name: wagtailsearch_querydailyhits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE wagtailsearch_querydailyhits_id_seq OWNED BY wagtailsearch_querydailyhits.id;


--
-- Name: wagtailusers_userprofile; Type: TABLE; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE TABLE wagtailusers_userprofile (
    id integer NOT NULL,
    submitted_notifications boolean NOT NULL,
    approved_notifications boolean NOT NULL,
    rejected_notifications boolean NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.wagtailusers_userprofile OWNER TO tyndale;

--
-- Name: wagtailusers_userprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: tyndale
--

CREATE SEQUENCE wagtailusers_userprofile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wagtailusers_userprofile_id_seq OWNER TO tyndale;

--
-- Name: wagtailusers_userprofile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tyndale
--

ALTER SEQUENCE wagtailusers_userprofile_id_seq OWNED BY wagtailusers_userprofile.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY customuser_user ALTER COLUMN id SET DEFAULT nextval('customuser_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY customuser_user_groups ALTER COLUMN id SET DEFAULT nextval('customuser_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY customuser_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('customuser_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY easy_thumbnails_source ALTER COLUMN id SET DEFAULT nextval('easy_thumbnails_source_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY easy_thumbnails_thumbnail ALTER COLUMN id SET DEFAULT nextval('easy_thumbnails_thumbnail_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY easy_thumbnails_thumbnaildimensions ALTER COLUMN id SET DEFAULT nextval('easy_thumbnails_thumbnaildimensions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_academicprograms ALTER COLUMN id SET DEFAULT nextval('home_academicprograms_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_adjunctprofessor ALTER COLUMN id SET DEFAULT nextval('home_adjunctprofessor_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_course ALTER COLUMN id SET DEFAULT nextval('home_course_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_formfield ALTER COLUMN id SET DEFAULT nextval('home_formfield_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_professor ALTER COLUMN id SET DEFAULT nextval('home_professor_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY taggit_tag ALTER COLUMN id SET DEFAULT nextval('taggit_tag_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY taggit_taggeditem ALTER COLUMN id SET DEFAULT nextval('taggit_taggeditem_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailcore_grouppagepermission ALTER COLUMN id SET DEFAULT nextval('wagtailcore_grouppagepermission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailcore_page ALTER COLUMN id SET DEFAULT nextval('wagtailcore_page_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailcore_pagerevision ALTER COLUMN id SET DEFAULT nextval('wagtailcore_pagerevision_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailcore_pageviewrestriction ALTER COLUMN id SET DEFAULT nextval('wagtailcore_pageviewrestriction_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailcore_site ALTER COLUMN id SET DEFAULT nextval('wagtailcore_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtaildocs_document ALTER COLUMN id SET DEFAULT nextval('wagtaildocs_document_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailembeds_embed ALTER COLUMN id SET DEFAULT nextval('wagtailembeds_embed_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailforms_formsubmission ALTER COLUMN id SET DEFAULT nextval('wagtailforms_formsubmission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailimages_filter ALTER COLUMN id SET DEFAULT nextval('wagtailimages_filter_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailimages_image ALTER COLUMN id SET DEFAULT nextval('wagtailimages_image_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailimages_rendition ALTER COLUMN id SET DEFAULT nextval('wagtailimages_rendition_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailredirects_redirect ALTER COLUMN id SET DEFAULT nextval('wagtailredirects_redirect_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailsearch_editorspick ALTER COLUMN id SET DEFAULT nextval('wagtailsearch_editorspick_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailsearch_query ALTER COLUMN id SET DEFAULT nextval('wagtailsearch_query_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailsearch_querydailyhits ALTER COLUMN id SET DEFAULT nextval('wagtailsearch_querydailyhits_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailusers_userprofile ALTER COLUMN id SET DEFAULT nextval('wagtailusers_userprofile_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY auth_group (id, name) FROM stdin;
\.
COPY auth_group (id, name) FROM '$$PATH$$/2573.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('auth_group_id_seq', 2, true);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/2575.dat';

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 14, true);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/2571.dat';

--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('auth_permission_id_seq', 136, true);


--
-- Data for Name: customuser_user; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY customuser_user (id, password, last_login, is_superuser, email, is_staff, is_active, date_joined, last_name, first_name) FROM stdin;
\.
COPY customuser_user (id, password, last_login, is_superuser, email, is_staff, is_active, date_joined, last_name, first_name) FROM '$$PATH$$/2577.dat';

--
-- Data for Name: customuser_user_groups; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY customuser_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY customuser_user_groups (id, user_id, group_id) FROM '$$PATH$$/2579.dat';

--
-- Name: customuser_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('customuser_user_groups_id_seq', 1, false);


--
-- Name: customuser_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('customuser_user_id_seq', 1, true);


--
-- Data for Name: customuser_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY customuser_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY customuser_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/2581.dat';

--
-- Name: customuser_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('customuser_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/2583.dat';

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 1, false);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY django_content_type (id, app_label, model) FROM stdin;
\.
COPY django_content_type (id, app_label, model) FROM '$$PATH$$/2569.dat';

--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('django_content_type_id_seq', 46, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY django_migrations (id, app, name, applied) FROM stdin;
\.
COPY django_migrations (id, app, name, applied) FROM '$$PATH$$/2567.dat';

--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('django_migrations_id_seq', 56, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY django_session (session_key, session_data, expire_date) FROM '$$PATH$$/2633.dat';

--
-- Data for Name: easy_thumbnails_source; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY easy_thumbnails_source (id, storage_hash, name, modified) FROM stdin;
\.
COPY easy_thumbnails_source (id, storage_hash, name, modified) FROM '$$PATH$$/2585.dat';

--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('easy_thumbnails_source_id_seq', 1, false);


--
-- Data for Name: easy_thumbnails_thumbnail; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY easy_thumbnails_thumbnail (id, storage_hash, name, modified, source_id) FROM stdin;
\.
COPY easy_thumbnails_thumbnail (id, storage_hash, name, modified, source_id) FROM '$$PATH$$/2587.dat';

--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('easy_thumbnails_thumbnail_id_seq', 1, false);


--
-- Data for Name: easy_thumbnails_thumbnaildimensions; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY easy_thumbnails_thumbnaildimensions (id, thumbnail_id, width, height) FROM stdin;
\.
COPY easy_thumbnails_thumbnaildimensions (id, thumbnail_id, width, height) FROM '$$PATH$$/2589.dat';

--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('easy_thumbnails_thumbnaildimensions_id_seq', 1, false);


--
-- Data for Name: home_aboutpage; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY home_aboutpage (page_ptr_id, subsection_title, subsection_subtitle, body, main_image_id) FROM stdin;
\.
COPY home_aboutpage (page_ptr_id, subsection_title, subsection_subtitle, body, main_image_id) FROM '$$PATH$$/2611.dat';

--
-- Data for Name: home_academicpage; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY home_academicpage (page_ptr_id, subsection_title, subsection_subtitle, body, main_image_id) FROM stdin;
\.
COPY home_academicpage (page_ptr_id, subsection_title, subsection_subtitle, body, main_image_id) FROM '$$PATH$$/2612.dat';

--
-- Data for Name: home_academicprogrampage; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY home_academicprogrampage (page_ptr_id, subsection_title, subsection_subtitle) FROM stdin;
\.
COPY home_academicprogrampage (page_ptr_id, subsection_title, subsection_subtitle) FROM '$$PATH$$/2613.dat';

--
-- Data for Name: home_academicprograms; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY home_academicprograms (id, program_name, program_description) FROM stdin;
\.
COPY home_academicprograms (id, program_name, program_description) FROM '$$PATH$$/2615.dat';

--
-- Name: home_academicprograms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('home_academicprograms_id_seq', 1, false);


--
-- Data for Name: home_adjunctprofessor; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY home_adjunctprofessor (id, professor_name, professor_spec, professor_course, professor_image_id) FROM stdin;
\.
COPY home_adjunctprofessor (id, professor_name, professor_spec, professor_course, professor_image_id) FROM '$$PATH$$/2617.dat';

--
-- Name: home_adjunctprofessor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('home_adjunctprofessor_id_seq', 1, false);


--
-- Data for Name: home_admissionpage; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY home_admissionpage (page_ptr_id, subsection_title, subsection_subtitle, body, main_image_id) FROM stdin;
\.
COPY home_admissionpage (page_ptr_id, subsection_title, subsection_subtitle, body, main_image_id) FROM '$$PATH$$/2618.dat';

--
-- Data for Name: home_chairmanpage; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY home_chairmanpage (page_ptr_id, subsection_title, subsection_subtitle, chairman_name, chairman_title, body, chairman_image_id) FROM stdin;
\.
COPY home_chairmanpage (page_ptr_id, subsection_title, subsection_subtitle, chairman_name, chairman_title, body, chairman_image_id) FROM '$$PATH$$/2619.dat';

--
-- Data for Name: home_contactpage; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY home_contactpage (page_ptr_id, to_address, from_address, subject, contact_header, contact_subheader, thank_you_text) FROM stdin;
\.
COPY home_contactpage (page_ptr_id, to_address, from_address, subject, contact_header, contact_subheader, thank_you_text) FROM '$$PATH$$/2620.dat';

--
-- Data for Name: home_course; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY home_course (id, course_name) FROM stdin;
\.
COPY home_course (id, course_name) FROM '$$PATH$$/2622.dat';

--
-- Name: home_course_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('home_course_id_seq', 1, false);


--
-- Data for Name: home_facultypage; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY home_facultypage (page_ptr_id, subsection_title, subsection_subtitle, tab_title_1, tab_title_2) FROM stdin;
\.
COPY home_facultypage (page_ptr_id, subsection_title, subsection_subtitle, tab_title_1, tab_title_2) FROM '$$PATH$$/2623.dat';

--
-- Data for Name: home_faithpage; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY home_faithpage (page_ptr_id, subsection_title, subsection_subtitle, body, main_image_id) FROM stdin;
\.
COPY home_faithpage (page_ptr_id, subsection_title, subsection_subtitle, body, main_image_id) FROM '$$PATH$$/2624.dat';

--
-- Data for Name: home_formfield; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY home_formfield (id, sort_order, label, field_type, required, choices, default_value, help_text, page_id) FROM stdin;
\.
COPY home_formfield (id, sort_order, label, field_type, required, choices, default_value, help_text, page_id) FROM '$$PATH$$/2626.dat';

--
-- Name: home_formfield_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('home_formfield_id_seq', 1, false);


--
-- Data for Name: home_homepage; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY home_homepage (page_ptr_id, main_header, main_subheader, slider1_header1, slider1_header2, slider1_subheader1, slider2_header1, slider2_subheader1) FROM stdin;
\.
COPY home_homepage (page_ptr_id, main_header, main_subheader, slider1_header1, slider1_header2, slider1_subheader1, slider2_header1, slider2_subheader1) FROM '$$PATH$$/2610.dat';

--
-- Data for Name: home_missionpage; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY home_missionpage (page_ptr_id, subsection_title, subsection_subtitle, body, main_image_id) FROM stdin;
\.
COPY home_missionpage (page_ptr_id, subsection_title, subsection_subtitle, body, main_image_id) FROM '$$PATH$$/2627.dat';

--
-- Data for Name: home_presidentpage; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY home_presidentpage (page_ptr_id, subsection_title, subsection_subtitle, president_name, president_title, body, president_image_id) FROM stdin;
\.
COPY home_presidentpage (page_ptr_id, subsection_title, subsection_subtitle, president_name, president_title, body, president_image_id) FROM '$$PATH$$/2628.dat';

--
-- Data for Name: home_professor; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY home_professor (id, professor_name, professor_spec, course_id, professor_image_id) FROM stdin;
\.
COPY home_professor (id, professor_name, professor_spec, course_id, professor_image_id) FROM '$$PATH$$/2630.dat';

--
-- Name: home_professor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('home_professor_id_seq', 1, false);


--
-- Data for Name: home_staffpage; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY home_staffpage (page_ptr_id, subsection_title, subsection_subtitle, first_column_header, first_column_name, first_column_position, first_column_spec, second_column_header, second_column_name, second_column_position, second_column_spec, third_column_header, third_column_name, third_column_position, fourth_column_header, fourth_column_name, fourth_column_position, fifth_column_header, fifth_column_name, fifth_column_position, fifth_column_image_id, first_column_image_id, fourth_column_image_id, second_column_image_id, third_column_image_id) FROM stdin;
\.
COPY home_staffpage (page_ptr_id, subsection_title, subsection_subtitle, first_column_header, first_column_name, first_column_position, first_column_spec, second_column_header, second_column_name, second_column_position, second_column_spec, third_column_header, third_column_name, third_column_position, fourth_column_header, fourth_column_name, fourth_column_position, fifth_column_header, fifth_column_name, fifth_column_position, fifth_column_image_id, first_column_image_id, fourth_column_image_id, second_column_image_id, third_column_image_id) FROM '$$PATH$$/2631.dat';

--
-- Data for Name: profiles_profile; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY profiles_profile (user_id, slug, picture, bio, email_verified) FROM stdin;
\.
COPY profiles_profile (user_id, slug, picture, bio, email_verified) FROM '$$PATH$$/2632.dat';

--
-- Data for Name: taggit_tag; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY taggit_tag (id, name, slug) FROM stdin;
\.
COPY taggit_tag (id, name, slug) FROM '$$PATH$$/2591.dat';

--
-- Name: taggit_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('taggit_tag_id_seq', 1, false);


--
-- Data for Name: taggit_taggeditem; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY taggit_taggeditem (id, object_id, content_type_id, tag_id) FROM stdin;
\.
COPY taggit_taggeditem (id, object_id, content_type_id, tag_id) FROM '$$PATH$$/2593.dat';

--
-- Name: taggit_taggeditem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('taggit_taggeditem_id_seq', 1, false);


--
-- Data for Name: wagtailcore_grouppagepermission; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY wagtailcore_grouppagepermission (id, permission_type, group_id, page_id) FROM stdin;
\.
COPY wagtailcore_grouppagepermission (id, permission_type, group_id, page_id) FROM '$$PATH$$/2603.dat';

--
-- Name: wagtailcore_grouppagepermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('wagtailcore_grouppagepermission_id_seq', 6, true);


--
-- Data for Name: wagtailcore_page; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY wagtailcore_page (id, path, depth, numchild, title, slug, live, has_unpublished_changes, url_path, seo_title, show_in_menus, search_description, go_live_at, expire_at, expired, content_type_id, owner_id, locked, latest_revision_created_at, first_published_at) FROM stdin;
\.
COPY wagtailcore_page (id, path, depth, numchild, title, slug, live, has_unpublished_changes, url_path, seo_title, show_in_menus, search_description, go_live_at, expire_at, expired, content_type_id, owner_id, locked, latest_revision_created_at, first_published_at) FROM '$$PATH$$/2601.dat';

--
-- Name: wagtailcore_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('wagtailcore_page_id_seq', 6, true);


--
-- Data for Name: wagtailcore_pagerevision; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY wagtailcore_pagerevision (id, submitted_for_moderation, created_at, content_json, approved_go_live_at, page_id, user_id) FROM stdin;
\.
COPY wagtailcore_pagerevision (id, submitted_for_moderation, created_at, content_json, approved_go_live_at, page_id, user_id) FROM '$$PATH$$/2605.dat';

--
-- Name: wagtailcore_pagerevision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('wagtailcore_pagerevision_id_seq', 9, true);


--
-- Data for Name: wagtailcore_pageviewrestriction; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY wagtailcore_pageviewrestriction (id, password, page_id) FROM stdin;
\.
COPY wagtailcore_pageviewrestriction (id, password, page_id) FROM '$$PATH$$/2607.dat';

--
-- Name: wagtailcore_pageviewrestriction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('wagtailcore_pageviewrestriction_id_seq', 1, false);


--
-- Data for Name: wagtailcore_site; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY wagtailcore_site (id, hostname, port, is_default_site, root_page_id) FROM stdin;
\.
COPY wagtailcore_site (id, hostname, port, is_default_site, root_page_id) FROM '$$PATH$$/2609.dat';

--
-- Name: wagtailcore_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('wagtailcore_site_id_seq', 2, true);


--
-- Data for Name: wagtaildocs_document; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY wagtaildocs_document (id, title, file, created_at, uploaded_by_user_id) FROM stdin;
\.
COPY wagtaildocs_document (id, title, file, created_at, uploaded_by_user_id) FROM '$$PATH$$/2635.dat';

--
-- Name: wagtaildocs_document_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('wagtaildocs_document_id_seq', 1, false);


--
-- Data for Name: wagtailembeds_embed; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY wagtailembeds_embed (id, url, max_width, type, html, title, author_name, provider_name, thumbnail_url, width, height, last_updated) FROM stdin;
\.
COPY wagtailembeds_embed (id, url, max_width, type, html, title, author_name, provider_name, thumbnail_url, width, height, last_updated) FROM '$$PATH$$/2637.dat';

--
-- Name: wagtailembeds_embed_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('wagtailembeds_embed_id_seq', 1, false);


--
-- Data for Name: wagtailforms_formsubmission; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY wagtailforms_formsubmission (id, form_data, submit_time, page_id) FROM stdin;
\.
COPY wagtailforms_formsubmission (id, form_data, submit_time, page_id) FROM '$$PATH$$/2639.dat';

--
-- Name: wagtailforms_formsubmission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('wagtailforms_formsubmission_id_seq', 1, false);


--
-- Data for Name: wagtailimages_filter; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY wagtailimages_filter (id, spec) FROM stdin;
\.
COPY wagtailimages_filter (id, spec) FROM '$$PATH$$/2595.dat';

--
-- Name: wagtailimages_filter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('wagtailimages_filter_id_seq', 5, true);


--
-- Data for Name: wagtailimages_image; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY wagtailimages_image (id, title, file, width, height, created_at, focal_point_x, focal_point_y, focal_point_width, focal_point_height, uploaded_by_user_id) FROM stdin;
\.
COPY wagtailimages_image (id, title, file, width, height, created_at, focal_point_x, focal_point_y, focal_point_width, focal_point_height, uploaded_by_user_id) FROM '$$PATH$$/2597.dat';

--
-- Name: wagtailimages_image_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('wagtailimages_image_id_seq', 3, true);


--
-- Data for Name: wagtailimages_rendition; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY wagtailimages_rendition (id, file, width, height, focal_point_key, filter_id, image_id) FROM stdin;
\.
COPY wagtailimages_rendition (id, file, width, height, focal_point_key, filter_id, image_id) FROM '$$PATH$$/2599.dat';

--
-- Name: wagtailimages_rendition_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('wagtailimages_rendition_id_seq', 11, true);


--
-- Data for Name: wagtailredirects_redirect; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY wagtailredirects_redirect (id, old_path, is_permanent, redirect_link, redirect_page_id, site_id) FROM stdin;
\.
COPY wagtailredirects_redirect (id, old_path, is_permanent, redirect_link, redirect_page_id, site_id) FROM '$$PATH$$/2641.dat';

--
-- Name: wagtailredirects_redirect_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('wagtailredirects_redirect_id_seq', 1, false);


--
-- Data for Name: wagtailsearch_editorspick; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY wagtailsearch_editorspick (id, sort_order, description, page_id, query_id) FROM stdin;
\.
COPY wagtailsearch_editorspick (id, sort_order, description, page_id, query_id) FROM '$$PATH$$/2643.dat';

--
-- Name: wagtailsearch_editorspick_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('wagtailsearch_editorspick_id_seq', 1, false);


--
-- Data for Name: wagtailsearch_query; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY wagtailsearch_query (id, query_string) FROM stdin;
\.
COPY wagtailsearch_query (id, query_string) FROM '$$PATH$$/2645.dat';

--
-- Name: wagtailsearch_query_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('wagtailsearch_query_id_seq', 1, false);


--
-- Data for Name: wagtailsearch_querydailyhits; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY wagtailsearch_querydailyhits (id, date, hits, query_id) FROM stdin;
\.
COPY wagtailsearch_querydailyhits (id, date, hits, query_id) FROM '$$PATH$$/2647.dat';

--
-- Name: wagtailsearch_querydailyhits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('wagtailsearch_querydailyhits_id_seq', 1, false);


--
-- Data for Name: wagtailusers_userprofile; Type: TABLE DATA; Schema: public; Owner: tyndale
--

COPY wagtailusers_userprofile (id, submitted_notifications, approved_notifications, rejected_notifications, user_id) FROM stdin;
\.
COPY wagtailusers_userprofile (id, submitted_notifications, approved_notifications, rejected_notifications, user_id) FROM '$$PATH$$/2649.dat';

--
-- Name: wagtailusers_userprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tyndale
--

SELECT pg_catalog.setval('wagtailusers_userprofile_id_seq', 1, false);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_codename_key; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: customuser_user_email_key; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY customuser_user
    ADD CONSTRAINT customuser_user_email_key UNIQUE (email);


--
-- Name: customuser_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY customuser_user_groups
    ADD CONSTRAINT customuser_user_groups_pkey PRIMARY KEY (id);


--
-- Name: customuser_user_groups_user_id_group_id_key; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY customuser_user_groups
    ADD CONSTRAINT customuser_user_groups_user_id_group_id_key UNIQUE (user_id, group_id);


--
-- Name: customuser_user_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY customuser_user
    ADD CONSTRAINT customuser_user_pkey PRIMARY KEY (id);


--
-- Name: customuser_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY customuser_user_user_permissions
    ADD CONSTRAINT customuser_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: customuser_user_user_permissions_user_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY customuser_user_user_permissions
    ADD CONSTRAINT customuser_user_user_permissions_user_id_permission_id_key UNIQUE (user_id, permission_id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_dc43af67bcef15c_uniq; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_dc43af67bcef15c_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: easy_thumbnails_source_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY easy_thumbnails_source
    ADD CONSTRAINT easy_thumbnails_source_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_source_storage_hash_98d060f8ac60bfa_uniq; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY easy_thumbnails_source
    ADD CONSTRAINT easy_thumbnails_source_storage_hash_98d060f8ac60bfa_uniq UNIQUE (storage_hash, name);


--
-- Name: easy_thumbnails_thumbnail_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thumbnail_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_thumbnail_storage_hash_395d1722d4748222_uniq; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thumbnail_storage_hash_395d1722d4748222_uniq UNIQUE (storage_hash, name, source_id);


--
-- Name: easy_thumbnails_thumbnaildimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thumbnaildimensions_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_thumbnaildimensions_thumbnail_id_key; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thumbnaildimensions_thumbnail_id_key UNIQUE (thumbnail_id);


--
-- Name: home_aboutpage_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY home_aboutpage
    ADD CONSTRAINT home_aboutpage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: home_academicpage_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY home_academicpage
    ADD CONSTRAINT home_academicpage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: home_academicprogrampage_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY home_academicprogrampage
    ADD CONSTRAINT home_academicprogrampage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: home_academicprograms_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY home_academicprograms
    ADD CONSTRAINT home_academicprograms_pkey PRIMARY KEY (id);


--
-- Name: home_adjunctprofessor_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY home_adjunctprofessor
    ADD CONSTRAINT home_adjunctprofessor_pkey PRIMARY KEY (id);


--
-- Name: home_admissionpage_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY home_admissionpage
    ADD CONSTRAINT home_admissionpage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: home_chairmanpage_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY home_chairmanpage
    ADD CONSTRAINT home_chairmanpage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: home_contactpage_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY home_contactpage
    ADD CONSTRAINT home_contactpage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: home_course_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY home_course
    ADD CONSTRAINT home_course_pkey PRIMARY KEY (id);


--
-- Name: home_facultypage_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY home_facultypage
    ADD CONSTRAINT home_facultypage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: home_faithpage_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY home_faithpage
    ADD CONSTRAINT home_faithpage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: home_formfield_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY home_formfield
    ADD CONSTRAINT home_formfield_pkey PRIMARY KEY (id);


--
-- Name: home_homepage_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY home_homepage
    ADD CONSTRAINT home_homepage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: home_missionpage_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY home_missionpage
    ADD CONSTRAINT home_missionpage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: home_presidentpage_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY home_presidentpage
    ADD CONSTRAINT home_presidentpage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: home_professor_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY home_professor
    ADD CONSTRAINT home_professor_pkey PRIMARY KEY (id);


--
-- Name: home_staffpage_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY home_staffpage
    ADD CONSTRAINT home_staffpage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: profiles_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY profiles_profile
    ADD CONSTRAINT profiles_profile_pkey PRIMARY KEY (user_id);


--
-- Name: taggit_tag_name_key; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY taggit_tag
    ADD CONSTRAINT taggit_tag_name_key UNIQUE (name);


--
-- Name: taggit_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY taggit_tag
    ADD CONSTRAINT taggit_tag_pkey PRIMARY KEY (id);


--
-- Name: taggit_tag_slug_key; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY taggit_tag
    ADD CONSTRAINT taggit_tag_slug_key UNIQUE (slug);


--
-- Name: taggit_taggeditem_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_pkey PRIMARY KEY (id);


--
-- Name: wagtailcore_grouppagepermission_group_id_4518bd8ce5687df9_uniq; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailcore_grouppagepermission
    ADD CONSTRAINT wagtailcore_grouppagepermission_group_id_4518bd8ce5687df9_uniq UNIQUE (group_id, page_id, permission_type);


--
-- Name: wagtailcore_grouppagepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailcore_grouppagepermission
    ADD CONSTRAINT wagtailcore_grouppagepermission_pkey PRIMARY KEY (id);


--
-- Name: wagtailcore_page_path_key; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailcore_page
    ADD CONSTRAINT wagtailcore_page_path_key UNIQUE (path);


--
-- Name: wagtailcore_page_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailcore_page
    ADD CONSTRAINT wagtailcore_page_pkey PRIMARY KEY (id);


--
-- Name: wagtailcore_pagerevision_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailcore_pagerevision
    ADD CONSTRAINT wagtailcore_pagerevision_pkey PRIMARY KEY (id);


--
-- Name: wagtailcore_pageviewrestriction_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailcore_pageviewrestriction
    ADD CONSTRAINT wagtailcore_pageviewrestriction_pkey PRIMARY KEY (id);


--
-- Name: wagtailcore_site_hostname_2a80ef61b26e6749_uniq; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailcore_site
    ADD CONSTRAINT wagtailcore_site_hostname_2a80ef61b26e6749_uniq UNIQUE (hostname, port);


--
-- Name: wagtailcore_site_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailcore_site
    ADD CONSTRAINT wagtailcore_site_pkey PRIMARY KEY (id);


--
-- Name: wagtaildocs_document_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtaildocs_document
    ADD CONSTRAINT wagtaildocs_document_pkey PRIMARY KEY (id);


--
-- Name: wagtailembeds_embed_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailembeds_embed
    ADD CONSTRAINT wagtailembeds_embed_pkey PRIMARY KEY (id);


--
-- Name: wagtailembeds_embed_url_7e0691a718dc9c01_uniq; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailembeds_embed
    ADD CONSTRAINT wagtailembeds_embed_url_7e0691a718dc9c01_uniq UNIQUE (url, max_width);


--
-- Name: wagtailforms_formsubmission_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailforms_formsubmission
    ADD CONSTRAINT wagtailforms_formsubmission_pkey PRIMARY KEY (id);


--
-- Name: wagtailimages_filter_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailimages_filter
    ADD CONSTRAINT wagtailimages_filter_pkey PRIMARY KEY (id);


--
-- Name: wagtailimages_filter_spec_409923649c6ba3fd_uniq; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailimages_filter
    ADD CONSTRAINT wagtailimages_filter_spec_409923649c6ba3fd_uniq UNIQUE (spec);


--
-- Name: wagtailimages_image_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailimages_image
    ADD CONSTRAINT wagtailimages_image_pkey PRIMARY KEY (id);


--
-- Name: wagtailimages_rendition_image_id_490eb468027bb6fd_uniq; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailimages_rendition
    ADD CONSTRAINT wagtailimages_rendition_image_id_490eb468027bb6fd_uniq UNIQUE (image_id, filter_id, focal_point_key);


--
-- Name: wagtailimages_rendition_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailimages_rendition
    ADD CONSTRAINT wagtailimages_rendition_pkey PRIMARY KEY (id);


--
-- Name: wagtailredirects_redirect_old_path_key; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailredirects_redirect
    ADD CONSTRAINT wagtailredirects_redirect_old_path_key UNIQUE (old_path);


--
-- Name: wagtailredirects_redirect_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailredirects_redirect
    ADD CONSTRAINT wagtailredirects_redirect_pkey PRIMARY KEY (id);


--
-- Name: wagtailsearch_editorspick_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailsearch_editorspick
    ADD CONSTRAINT wagtailsearch_editorspick_pkey PRIMARY KEY (id);


--
-- Name: wagtailsearch_query_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailsearch_query
    ADD CONSTRAINT wagtailsearch_query_pkey PRIMARY KEY (id);


--
-- Name: wagtailsearch_query_query_string_key; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailsearch_query
    ADD CONSTRAINT wagtailsearch_query_query_string_key UNIQUE (query_string);


--
-- Name: wagtailsearch_querydailyhits_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailsearch_querydailyhits
    ADD CONSTRAINT wagtailsearch_querydailyhits_pkey PRIMARY KEY (id);


--
-- Name: wagtailsearch_querydailyhits_query_id_79086747560278_uniq; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailsearch_querydailyhits
    ADD CONSTRAINT wagtailsearch_querydailyhits_query_id_79086747560278_uniq UNIQUE (query_id, date);


--
-- Name: wagtailusers_userprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailusers_userprofile
    ADD CONSTRAINT wagtailusers_userprofile_pkey PRIMARY KEY (id);


--
-- Name: wagtailusers_userprofile_user_id_key; Type: CONSTRAINT; Schema: public; Owner: tyndale; Tablespace: 
--

ALTER TABLE ONLY wagtailusers_userprofile
    ADD CONSTRAINT wagtailusers_userprofile_user_id_key UNIQUE (user_id);


--
-- Name: auth_group_name_7665a36bbdb67308_like; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX auth_group_name_7665a36bbdb67308_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX auth_group_permissions_0e939a4f ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX auth_group_permissions_8373b171 ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX auth_permission_417f1b1c ON auth_permission USING btree (content_type_id);


--
-- Name: customuser_user_email_159630748200931_like; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX customuser_user_email_159630748200931_like ON customuser_user USING btree (email varchar_pattern_ops);


--
-- Name: customuser_user_groups_0e939a4f; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX customuser_user_groups_0e939a4f ON customuser_user_groups USING btree (group_id);


--
-- Name: customuser_user_groups_e8701ad4; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX customuser_user_groups_e8701ad4 ON customuser_user_groups USING btree (user_id);


--
-- Name: customuser_user_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX customuser_user_user_permissions_8373b171 ON customuser_user_user_permissions USING btree (permission_id);


--
-- Name: customuser_user_user_permissions_e8701ad4; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX customuser_user_user_permissions_e8701ad4 ON customuser_user_user_permissions USING btree (user_id);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX django_admin_log_417f1b1c ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX django_admin_log_e8701ad4 ON django_admin_log USING btree (user_id);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX django_session_de54fa62 ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_3fb33b5fdd87a86f_like; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX django_session_session_key_3fb33b5fdd87a86f_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: easy_thumbnails_source_b068931c; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX easy_thumbnails_source_b068931c ON easy_thumbnails_source USING btree (name);


--
-- Name: easy_thumbnails_source_b454e115; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX easy_thumbnails_source_b454e115 ON easy_thumbnails_source USING btree (storage_hash);


--
-- Name: easy_thumbnails_source_name_38cbc7eb65fc261b_like; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX easy_thumbnails_source_name_38cbc7eb65fc261b_like ON easy_thumbnails_source USING btree (name varchar_pattern_ops);


--
-- Name: easy_thumbnails_source_storage_hash_417781e295d0ceee_like; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX easy_thumbnails_source_storage_hash_417781e295d0ceee_like ON easy_thumbnails_source USING btree (storage_hash varchar_pattern_ops);


--
-- Name: easy_thumbnails_thumbnail_0afd9202; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX easy_thumbnails_thumbnail_0afd9202 ON easy_thumbnails_thumbnail USING btree (source_id);


--
-- Name: easy_thumbnails_thumbnail_b068931c; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX easy_thumbnails_thumbnail_b068931c ON easy_thumbnails_thumbnail USING btree (name);


--
-- Name: easy_thumbnails_thumbnail_b454e115; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX easy_thumbnails_thumbnail_b454e115 ON easy_thumbnails_thumbnail USING btree (storage_hash);


--
-- Name: easy_thumbnails_thumbnail_name_c03c5337b1aa13c_like; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX easy_thumbnails_thumbnail_name_c03c5337b1aa13c_like ON easy_thumbnails_thumbnail USING btree (name varchar_pattern_ops);


--
-- Name: easy_thumbnails_thumbnail_storage_hash_6f4dc48e20d434c1_like; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX easy_thumbnails_thumbnail_storage_hash_6f4dc48e20d434c1_like ON easy_thumbnails_thumbnail USING btree (storage_hash varchar_pattern_ops);


--
-- Name: home_aboutpage_36b62cbe; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX home_aboutpage_36b62cbe ON home_aboutpage USING btree (main_image_id);


--
-- Name: home_academicpage_36b62cbe; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX home_academicpage_36b62cbe ON home_academicpage USING btree (main_image_id);


--
-- Name: home_adjunctprofessor_628c0510; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX home_adjunctprofessor_628c0510 ON home_adjunctprofessor USING btree (professor_image_id);


--
-- Name: home_admissionpage_36b62cbe; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX home_admissionpage_36b62cbe ON home_admissionpage USING btree (main_image_id);


--
-- Name: home_chairmanpage_c24e8e1f; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX home_chairmanpage_c24e8e1f ON home_chairmanpage USING btree (chairman_image_id);


--
-- Name: home_faithpage_36b62cbe; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX home_faithpage_36b62cbe ON home_faithpage USING btree (main_image_id);


--
-- Name: home_formfield_1a63c800; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX home_formfield_1a63c800 ON home_formfield USING btree (page_id);


--
-- Name: home_missionpage_36b62cbe; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX home_missionpage_36b62cbe ON home_missionpage USING btree (main_image_id);


--
-- Name: home_presidentpage_95be3c30; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX home_presidentpage_95be3c30 ON home_presidentpage USING btree (president_image_id);


--
-- Name: home_professor_628c0510; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX home_professor_628c0510 ON home_professor USING btree (professor_image_id);


--
-- Name: home_professor_ea134da7; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX home_professor_ea134da7 ON home_professor USING btree (course_id);


--
-- Name: home_staffpage_225a5e91; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX home_staffpage_225a5e91 ON home_staffpage USING btree (fifth_column_image_id);


--
-- Name: home_staffpage_6f0924fe; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX home_staffpage_6f0924fe ON home_staffpage USING btree (fourth_column_image_id);


--
-- Name: home_staffpage_a18b3be8; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX home_staffpage_a18b3be8 ON home_staffpage USING btree (third_column_image_id);


--
-- Name: home_staffpage_b238208f; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX home_staffpage_b238208f ON home_staffpage USING btree (first_column_image_id);


--
-- Name: home_staffpage_ba834c48; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX home_staffpage_ba834c48 ON home_staffpage USING btree (second_column_image_id);


--
-- Name: taggit_tag_name_352a4f53e1e6cf47_like; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX taggit_tag_name_352a4f53e1e6cf47_like ON taggit_tag USING btree (name varchar_pattern_ops);


--
-- Name: taggit_tag_slug_7b53216b5eb30e7a_like; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX taggit_tag_slug_7b53216b5eb30e7a_like ON taggit_tag USING btree (slug varchar_pattern_ops);


--
-- Name: taggit_taggeditem_417f1b1c; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX taggit_taggeditem_417f1b1c ON taggit_taggeditem USING btree (content_type_id);


--
-- Name: taggit_taggeditem_76f094bc; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX taggit_taggeditem_76f094bc ON taggit_taggeditem USING btree (tag_id);


--
-- Name: taggit_taggeditem_af31437c; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX taggit_taggeditem_af31437c ON taggit_taggeditem USING btree (object_id);


--
-- Name: wagtailcore_grouppagepermission_0e939a4f; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailcore_grouppagepermission_0e939a4f ON wagtailcore_grouppagepermission USING btree (group_id);


--
-- Name: wagtailcore_grouppagepermission_1a63c800; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailcore_grouppagepermission_1a63c800 ON wagtailcore_grouppagepermission USING btree (page_id);


--
-- Name: wagtailcore_page_2dbcba41; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailcore_page_2dbcba41 ON wagtailcore_page USING btree (slug);


--
-- Name: wagtailcore_page_417f1b1c; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailcore_page_417f1b1c ON wagtailcore_page USING btree (content_type_id);


--
-- Name: wagtailcore_page_5e7b1936; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailcore_page_5e7b1936 ON wagtailcore_page USING btree (owner_id);


--
-- Name: wagtailcore_page_path_1d96dbce42ce3047_like; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailcore_page_path_1d96dbce42ce3047_like ON wagtailcore_page USING btree (path varchar_pattern_ops);


--
-- Name: wagtailcore_page_slug_33cd6a503184f996_like; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailcore_page_slug_33cd6a503184f996_like ON wagtailcore_page USING btree (slug varchar_pattern_ops);


--
-- Name: wagtailcore_pagerevision_1a63c800; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailcore_pagerevision_1a63c800 ON wagtailcore_pagerevision USING btree (page_id);


--
-- Name: wagtailcore_pagerevision_e8701ad4; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailcore_pagerevision_e8701ad4 ON wagtailcore_pagerevision USING btree (user_id);


--
-- Name: wagtailcore_pageviewrestriction_1a63c800; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailcore_pageviewrestriction_1a63c800 ON wagtailcore_pageviewrestriction USING btree (page_id);


--
-- Name: wagtailcore_site_0897acf4; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailcore_site_0897acf4 ON wagtailcore_site USING btree (hostname);


--
-- Name: wagtailcore_site_8372b497; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailcore_site_8372b497 ON wagtailcore_site USING btree (root_page_id);


--
-- Name: wagtailcore_site_hostname_3ffbf6d0334f7d6a_like; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailcore_site_hostname_3ffbf6d0334f7d6a_like ON wagtailcore_site USING btree (hostname varchar_pattern_ops);


--
-- Name: wagtaildocs_document_ef01e2b6; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtaildocs_document_ef01e2b6 ON wagtaildocs_document USING btree (uploaded_by_user_id);


--
-- Name: wagtailforms_formsubmission_1a63c800; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailforms_formsubmission_1a63c800 ON wagtailforms_formsubmission USING btree (page_id);


--
-- Name: wagtailimages_filter_b979c293; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailimages_filter_b979c293 ON wagtailimages_filter USING btree (spec);


--
-- Name: wagtailimages_filter_spec_409923649c6ba3fd_like; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailimages_filter_spec_409923649c6ba3fd_like ON wagtailimages_filter USING btree (spec varchar_pattern_ops);


--
-- Name: wagtailimages_image_ef01e2b6; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailimages_image_ef01e2b6 ON wagtailimages_image USING btree (uploaded_by_user_id);


--
-- Name: wagtailimages_rendition_0a317463; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailimages_rendition_0a317463 ON wagtailimages_rendition USING btree (filter_id);


--
-- Name: wagtailimages_rendition_f33175e6; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailimages_rendition_f33175e6 ON wagtailimages_rendition USING btree (image_id);


--
-- Name: wagtailredirects_redirect_2fd79f37; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailredirects_redirect_2fd79f37 ON wagtailredirects_redirect USING btree (redirect_page_id);


--
-- Name: wagtailredirects_redirect_9365d6e7; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailredirects_redirect_9365d6e7 ON wagtailredirects_redirect USING btree (site_id);


--
-- Name: wagtailredirects_redirect_old_path_610b66b8a211c03b_like; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailredirects_redirect_old_path_610b66b8a211c03b_like ON wagtailredirects_redirect USING btree (old_path varchar_pattern_ops);


--
-- Name: wagtailsearch_editorspick_0bbeda9c; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailsearch_editorspick_0bbeda9c ON wagtailsearch_editorspick USING btree (query_id);


--
-- Name: wagtailsearch_editorspick_1a63c800; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailsearch_editorspick_1a63c800 ON wagtailsearch_editorspick USING btree (page_id);


--
-- Name: wagtailsearch_query_query_string_6a2554201de9f1b_like; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailsearch_query_query_string_6a2554201de9f1b_like ON wagtailsearch_query USING btree (query_string varchar_pattern_ops);


--
-- Name: wagtailsearch_querydailyhits_0bbeda9c; Type: INDEX; Schema: public; Owner: tyndale; Tablespace: 
--

CREATE INDEX wagtailsearch_querydailyhits_0bbeda9c ON wagtailsearch_querydailyhits USING btree (query_id);


--
-- Name: D2f0c6e3dccb01e002c5eed7060c3b9a; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_staffpage
    ADD CONSTRAINT "D2f0c6e3dccb01e002c5eed7060c3b9a" FOREIGN KEY (first_column_image_id) REFERENCES wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_content_type_id_426ec875366b3dda_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_content_type_id_426ec875366b3dda_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permission_group_id_57fc07628a848d9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permission_group_id_57fc07628a848d9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permission_id_52013bedfbcc4057_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permission_id_52013bedfbcc4057_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bf4b8a9dd09e1b56f992b1b4b6d62dbf; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_staffpage
    ADD CONSTRAINT bf4b8a9dd09e1b56f992b1b4b6d62dbf FOREIGN KEY (fifth_column_image_id) REFERENCES wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: c1ac98a69b14ccd9c1595f81c3822d18; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_staffpage
    ADD CONSTRAINT c1ac98a69b14ccd9c1595f81c3822d18 FOREIGN KEY (third_column_image_id) REFERENCES wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customuser_permission_id_77bfc76393ec8d65_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY customuser_user_user_permissions
    ADD CONSTRAINT customuser_permission_id_77bfc76393ec8d65_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customuser_user__user_id_231de73d12ca3cd3_fk_customuser_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY customuser_user_groups
    ADD CONSTRAINT customuser_user__user_id_231de73d12ca3cd3_fk_customuser_user_id FOREIGN KEY (user_id) REFERENCES customuser_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customuser_user__user_id_25455e421d51c4de_fk_customuser_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY customuser_user_user_permissions
    ADD CONSTRAINT customuser_user__user_id_25455e421d51c4de_fk_customuser_user_id FOREIGN KEY (user_id) REFERENCES customuser_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customuser_user_groups_group_id_2f7fdf258880a2_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY customuser_user_groups
    ADD CONSTRAINT customuser_user_groups_group_id_2f7fdf258880a2_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djan_content_type_id_6a613939832fcaa7_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT djan_content_type_id_6a613939832fcaa7_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_78f04b5cdc41908b_fk_customuser_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_78f04b5cdc41908b_fk_customuser_user_id FOREIGN KEY (user_id) REFERENCES customuser_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: e_thumbnail_id_3e013d57ce7e94cb_fk_easy_thumbnails_thumbnail_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT e_thumbnail_id_3e013d57ce7e94cb_fk_easy_thumbnails_thumbnail_id FOREIGN KEY (thumbnail_id) REFERENCES easy_thumbnails_thumbnail(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: easy_th_source_id_321805aede6687c9_fk_easy_thumbnails_source_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_th_source_id_321805aede6687c9_fk_easy_thumbnails_source_id FOREIGN KEY (source_id) REFERENCES easy_thumbnails_source(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ec6cc53404e4a4ee3f3e85f90f0b07cd; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_staffpage
    ADD CONSTRAINT ec6cc53404e4a4ee3f3e85f90f0b07cd FOREIGN KEY (second_column_image_id) REFERENCES wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: fd8df23644a5bfe320428e6a741c48da; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_staffpage
    ADD CONSTRAINT fd8df23644a5bfe320428e6a741c48da FOREIGN KEY (fourth_column_image_id) REFERENCES wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: h_president_image_id_5b6916ce316916f9_fk_wagtailimages_image_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_presidentpage
    ADD CONSTRAINT h_president_image_id_5b6916ce316916f9_fk_wagtailimages_image_id FOREIGN KEY (president_image_id) REFERENCES wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: h_professor_image_id_4df2333f2c01e3b1_fk_wagtailimages_image_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_adjunctprofessor
    ADD CONSTRAINT h_professor_image_id_4df2333f2c01e3b1_fk_wagtailimages_image_id FOREIGN KEY (professor_image_id) REFERENCES wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ho_chairman_image_id_560f09c64138fe11_fk_wagtailimages_image_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_chairmanpage
    ADD CONSTRAINT ho_chairman_image_id_560f09c64138fe11_fk_wagtailimages_image_id FOREIGN KEY (chairman_image_id) REFERENCES wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ho_professor_image_id_48877a08374a4d2_fk_wagtailimages_image_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_professor
    ADD CONSTRAINT ho_professor_image_id_48877a08374a4d2_fk_wagtailimages_image_id FOREIGN KEY (professor_image_id) REFERENCES wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_a_main_image_id_341d070af76ca64d_fk_wagtailimages_image_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_admissionpage
    ADD CONSTRAINT home_a_main_image_id_341d070af76ca64d_fk_wagtailimages_image_id FOREIGN KEY (main_image_id) REFERENCES wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_a_main_image_id_48830c21360335ac_fk_wagtailimages_image_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_academicpage
    ADD CONSTRAINT home_a_main_image_id_48830c21360335ac_fk_wagtailimages_image_id FOREIGN KEY (main_image_id) REFERENCES wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_a_main_image_id_5da9735a12d9d323_fk_wagtailimages_image_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_aboutpage
    ADD CONSTRAINT home_a_main_image_id_5da9735a12d9d323_fk_wagtailimages_image_id FOREIGN KEY (main_image_id) REFERENCES wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_aboutp_page_ptr_id_4a7f55b5d4af4fe6_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_aboutpage
    ADD CONSTRAINT home_aboutp_page_ptr_id_4a7f55b5d4af4fe6_fk_wagtailcore_page_id FOREIGN KEY (page_ptr_id) REFERENCES wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_academ_page_ptr_id_55dae9875faad55d_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_academicpage
    ADD CONSTRAINT home_academ_page_ptr_id_55dae9875faad55d_fk_wagtailcore_page_id FOREIGN KEY (page_ptr_id) REFERENCES wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_academi_page_ptr_id_cf5b0d97595723c_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_academicprogrampage
    ADD CONSTRAINT home_academi_page_ptr_id_cf5b0d97595723c_fk_wagtailcore_page_id FOREIGN KEY (page_ptr_id) REFERENCES wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_admiss_page_ptr_id_4447d3be7c0844f6_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_admissionpage
    ADD CONSTRAINT home_admiss_page_ptr_id_4447d3be7c0844f6_fk_wagtailcore_page_id FOREIGN KEY (page_ptr_id) REFERENCES wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_chairm_page_ptr_id_769fe7b654b96b85_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_chairmanpage
    ADD CONSTRAINT home_chairm_page_ptr_id_769fe7b654b96b85_fk_wagtailcore_page_id FOREIGN KEY (page_ptr_id) REFERENCES wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_contac_page_ptr_id_54acbe67b0bbcf72_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_contactpage
    ADD CONSTRAINT home_contac_page_ptr_id_54acbe67b0bbcf72_fk_wagtailcore_page_id FOREIGN KEY (page_ptr_id) REFERENCES wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_f_main_image_id_4b4f54024b44b47a_fk_wagtailimages_image_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_faithpage
    ADD CONSTRAINT home_f_main_image_id_4b4f54024b44b47a_fk_wagtailimages_image_id FOREIGN KEY (main_image_id) REFERENCES wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_faculty_page_ptr_id_1dae642e5fc50d5_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_facultypage
    ADD CONSTRAINT home_faculty_page_ptr_id_1dae642e5fc50d5_fk_wagtailcore_page_id FOREIGN KEY (page_ptr_id) REFERENCES wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_faithp_page_ptr_id_6b5dbc2cfc940b8f_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_faithpage
    ADD CONSTRAINT home_faithp_page_ptr_id_6b5dbc2cfc940b8f_fk_wagtailcore_page_id FOREIGN KEY (page_ptr_id) REFERENCES wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_fo_page_id_540def10bdd5c57_fk_home_contactpage_page_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_formfield
    ADD CONSTRAINT home_fo_page_id_540def10bdd5c57_fk_home_contactpage_page_ptr_id FOREIGN KEY (page_id) REFERENCES home_contactpage(page_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_homepa_page_ptr_id_6b97572f83da83b6_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_homepage
    ADD CONSTRAINT home_homepa_page_ptr_id_6b97572f83da83b6_fk_wagtailcore_page_id FOREIGN KEY (page_ptr_id) REFERENCES wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_mi_main_image_id_bf5488bee3e0be7_fk_wagtailimages_image_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_missionpage
    ADD CONSTRAINT home_mi_main_image_id_bf5488bee3e0be7_fk_wagtailimages_image_id FOREIGN KEY (main_image_id) REFERENCES wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_missio_page_ptr_id_3200f609e1182c3e_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_missionpage
    ADD CONSTRAINT home_missio_page_ptr_id_3200f609e1182c3e_fk_wagtailcore_page_id FOREIGN KEY (page_ptr_id) REFERENCES wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_presid_page_ptr_id_62a75680a588fca1_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_presidentpage
    ADD CONSTRAINT home_presid_page_ptr_id_62a75680a588fca1_fk_wagtailcore_page_id FOREIGN KEY (page_ptr_id) REFERENCES wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_professor_course_id_702e5833cbb57b14_fk_home_course_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_professor
    ADD CONSTRAINT home_professor_course_id_702e5833cbb57b14_fk_home_course_id FOREIGN KEY (course_id) REFERENCES home_course(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_staffpa_page_ptr_id_b083750d8f35a16_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY home_staffpage
    ADD CONSTRAINT home_staffpa_page_ptr_id_b083750d8f35a16_fk_wagtailcore_page_id FOREIGN KEY (page_ptr_id) REFERENCES wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: profiles_profile_user_id_43e45dad59676234_fk_customuser_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY profiles_profile
    ADD CONSTRAINT profiles_profile_user_id_43e45dad59676234_fk_customuser_user_id FOREIGN KEY (user_id) REFERENCES customuser_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: taggi_content_type_id_de04cbca87b0d2f_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY taggit_taggeditem
    ADD CONSTRAINT taggi_content_type_id_de04cbca87b0d2f_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: taggit_taggeditem_tag_id_626bb7c335f8c891_fk_taggit_tag_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_tag_id_626bb7c335f8c891_fk_taggit_tag_id FOREIGN KEY (tag_id) REFERENCES taggit_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagt_content_type_id_41104bd3511ee9a9_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailcore_page
    ADD CONSTRAINT wagt_content_type_id_41104bd3511ee9a9_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagt_uploaded_by_user_id_10a3f7343c7d6b4b_fk_customuser_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtaildocs_document
    ADD CONSTRAINT wagt_uploaded_by_user_id_10a3f7343c7d6b4b_fk_customuser_user_id FOREIGN KEY (uploaded_by_user_id) REFERENCES customuser_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagt_uploaded_by_user_id_5f678b0be96600c4_fk_customuser_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailimages_image
    ADD CONSTRAINT wagt_uploaded_by_user_id_5f678b0be96600c4_fk_customuser_user_id FOREIGN KEY (uploaded_by_user_id) REFERENCES customuser_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtai_redirect_page_id_1fc1037e8cf399c4_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailredirects_redirect
    ADD CONSTRAINT wagtai_redirect_page_id_1fc1037e8cf399c4_fk_wagtailcore_page_id FOREIGN KEY (redirect_page_id) REFERENCES wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcor_root_page_id_3e30e080d28213b6_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailcore_site
    ADD CONSTRAINT wagtailcor_root_page_id_3e30e080d28213b6_fk_wagtailcore_page_id FOREIGN KEY (root_page_id) REFERENCES wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_gro_page_id_7b225fb90aae2549_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailcore_grouppagepermission
    ADD CONSTRAINT wagtailcore_gro_page_id_7b225fb90aae2549_fk_wagtailcore_page_id FOREIGN KEY (page_id) REFERENCES wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_grouppag_group_id_5e2917ffb767a184_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailcore_grouppagepermission
    ADD CONSTRAINT wagtailcore_grouppag_group_id_5e2917ffb767a184_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_pag_owner_id_769ea693e7256f60_fk_customuser_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailcore_page
    ADD CONSTRAINT wagtailcore_pag_owner_id_769ea693e7256f60_fk_customuser_user_id FOREIGN KEY (owner_id) REFERENCES customuser_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_pag_page_id_3696fe3bd41be929_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailcore_pageviewrestriction
    ADD CONSTRAINT wagtailcore_pag_page_id_3696fe3bd41be929_fk_wagtailcore_page_id FOREIGN KEY (page_id) REFERENCES wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_pag_page_id_7a085a6a003c2e38_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailcore_pagerevision
    ADD CONSTRAINT wagtailcore_pag_page_id_7a085a6a003c2e38_fk_wagtailcore_page_id FOREIGN KEY (page_id) REFERENCES wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailcore_page_user_id_482fed05cd73a514_fk_customuser_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailcore_pagerevision
    ADD CONSTRAINT wagtailcore_page_user_id_482fed05cd73a514_fk_customuser_user_id FOREIGN KEY (user_id) REFERENCES customuser_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailforms_fo_page_id_7776d182b41d08b3_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailforms_formsubmission
    ADD CONSTRAINT wagtailforms_fo_page_id_7776d182b41d08b3_fk_wagtailcore_page_id FOREIGN KEY (page_id) REFERENCES wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailim_filter_id_6afc387f605dd75c_fk_wagtailimages_filter_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailimages_rendition
    ADD CONSTRAINT wagtailim_filter_id_6afc387f605dd75c_fk_wagtailimages_filter_id FOREIGN KEY (filter_id) REFERENCES wagtailimages_filter(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailimag_image_id_2c8ddec62fb6f84b_fk_wagtailimages_image_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailimages_rendition
    ADD CONSTRAINT wagtailimag_image_id_2c8ddec62fb6f84b_fk_wagtailimages_image_id FOREIGN KEY (image_id) REFERENCES wagtailimages_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailredirect_site_id_7b7af15c0e80cbd4_fk_wagtailcore_site_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailredirects_redirect
    ADD CONSTRAINT wagtailredirect_site_id_7b7af15c0e80cbd4_fk_wagtailcore_site_id FOREIGN KEY (site_id) REFERENCES wagtailcore_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailsear_query_id_541f82ef755c7a39_fk_wagtailsearch_query_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailsearch_querydailyhits
    ADD CONSTRAINT wagtailsear_query_id_541f82ef755c7a39_fk_wagtailsearch_query_id FOREIGN KEY (query_id) REFERENCES wagtailsearch_query(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailsear_query_id_70b4a2d234a4eab8_fk_wagtailsearch_query_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailsearch_editorspick
    ADD CONSTRAINT wagtailsear_query_id_70b4a2d234a4eab8_fk_wagtailsearch_query_id FOREIGN KEY (query_id) REFERENCES wagtailsearch_query(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailsearch_e_page_id_361eed8faee37b94_fk_wagtailcore_page_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailsearch_editorspick
    ADD CONSTRAINT wagtailsearch_e_page_id_361eed8faee37b94_fk_wagtailcore_page_id FOREIGN KEY (page_id) REFERENCES wagtailcore_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: wagtailusers_use_user_id_140087ff955baad8_fk_customuser_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tyndale
--

ALTER TABLE ONLY wagtailusers_userprofile
    ADD CONSTRAINT wagtailusers_use_user_id_140087ff955baad8_fk_customuser_user_id FOREIGN KEY (user_id) REFERENCES customuser_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

